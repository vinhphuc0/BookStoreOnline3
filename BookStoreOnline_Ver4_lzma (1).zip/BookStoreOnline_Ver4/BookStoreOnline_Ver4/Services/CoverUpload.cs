﻿using System;
using System.IO;
using System.Linq;
using System.Web;

namespace BookStoreOnline.Services
{
    // Đọc tối đa 5 MB, không phụ thuộc hoàn toàn vào độ dài trình duyệt báo lên.
    public static class CoverUpload
    {
        public const int MaxBytes = 5 * 1024 * 1024;

        public static bool TryRead(HttpPostedFileBase cover, out byte[] bytes, out string extension, out string error)
        {
            bytes = null;
            extension = null;
            error = "";
            if (cover == null) return true;

            if (cover.ContentLength < 12 || cover.ContentLength > MaxBytes)
            {
                error = "Ảnh bìa phải là JPG hoặc PNG, không rỗng và không quá 5 MB.";
                return false;
            }

            try
            {
                var input = cover.InputStream;
                if (input == null)
                {
                    error = "Không nhận được dữ liệu ảnh. Hãy chọn lại tệp.";
                    return false;
                }
                using (var output = new MemoryStream())
                {
                    var buffer = new byte[8192];
                    int count;
                    while ((count = input.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        if (output.Length + count > MaxBytes)
                        {
                            error = "Ảnh bìa vượt quá 5 MB. Hãy chọn ảnh nhỏ hơn.";
                            return false;
                        }
                        output.Write(buffer, 0, count);
                    }
                    bytes = output.ToArray();
                }
            }
            catch (IOException)
            {
                error = "Chưa đọc được ảnh tải lên. Hãy chọn lại ảnh rồi lưu.";
                return false;
            }
            catch (HttpException)
            {
                error = "Yêu cầu tải ảnh chưa hoàn tất. Hãy chọn lại ảnh nhỏ hơn 5 MB.";
                return false;
            }

            if (bytes.Length < 12 || bytes.Length != cover.ContentLength)
            {
                error = "Ảnh tải lên bị thiếu dữ liệu. Hãy chọn lại ảnh.";
                return false;
            }

            bool jpeg = bytes[0] == 255 && bytes[1] == 216 && bytes[2] == 255;
            bool png = bytes.Take(8).SequenceEqual(new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 });
            if (!jpeg && !png)
            {
                error = "Chỉ nhận ảnh JPG hoặc PNG. Đổi đuôi tệp không chuyển được định dạng ảnh.";
                return false;
            }
            extension = jpeg ? ".jpg" : ".png";
            return true;
        }
    }
}
