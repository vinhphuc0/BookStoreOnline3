﻿using System;
using System.Collections.Generic;

namespace BookStoreOnline.Services
{
    public static class OrderRules
    {
        public static readonly string[] Statuses =
        {
            "Chờ thanh toán",
            "Đang xử lý",
            "Đang vận chuyển",
            "Đã giao",
            "Đã hủy"
        };
        public static readonly string[] Payments =
        {
            "Chờ thanh toán",
            "Đã thanh toán"
        };
        public static bool CanMove(string current, string next)
        {
            // Đơn đã giao hoặc đã hủy là trạng thái cuối.
            if (current == "Chờ thanh toán")
            {
                return next == "Đang xử lý" || next == "Đã hủy";
            }

            if (current == "Đang xử lý")
            {
                return next == "Đang vận chuyển" || next == "Đã hủy";
            }

            if (current == "Đang vận chuyển")
            {
                return next == "Đã giao" || next == "Đã hủy";
            }

            return false;
        }

        // Khách chỉ tự hủy khi cửa hàng chưa chuyển sang vận chuyển.
        public static bool CanCustomerCancel(string status, string paymentStatus)
        {
            return status == "Đang xử lý" && paymentStatus == "Chờ thanh toán";
        }

        public static string Code(int id)
        {
            return "BS" + id.ToString("D6");
        }

        public static bool TryId(string q, out int id)
        {
            q = (q ?? "").Trim();
            if (q.StartsWith("BS", StringComparison.OrdinalIgnoreCase))
            {
                q = q.Substring(2);
            }

            return int.TryParse(q, out id) && id > 0;
        }
    }
}
