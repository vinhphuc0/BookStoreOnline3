﻿using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Web;
using BookStoreOnline.Data;
using BookStoreOnline.ViewModels;

namespace BookStoreOnline.Services
{
    public class CartService
    {
        readonly HttpSessionStateBase session;
        readonly BookStoreContext db;
        public CartService(HttpSessionStateBase session, BookStoreContext db)
        {
            this.session = session;
            this.db = db;
        }

        // Session lưu giỏ riêng cho từng trình duyệt.
        public Dictionary<int, int> Get()
        {
            return session["Cart"] as Dictionary<int, int> ?? new Dictionary<int, int>();
        }

        public void Set(int id, int count)
        {
            var data = Get();
            if (count <= 0)
            {
                data.Remove(id);
            }
            else
            {
                data[id] = System.Math.Min(count, 20);
            }

            session["Cart"] = data;
            // Giỏ thay đổi thì form đặt hàng cũ cần được mở lại.
            session.Remove("CheckoutToken");
        }

        public void Clear()
        {
            session.Remove("Cart");
            session.Remove("CheckoutToken");
        }

        public int Count
        {
            get
            {
                return Get().Values.Sum();
            }
        }

        public List<CartLine> Lines()
        {
            var quantities = Get();
            var ids = quantities.Keys.ToList();
            // Lấy sách từ database trước, sau đó ghép số lượng trong Session.
            var books = db.Books.AsNoTracking().Include(x => x.Author).Where(x => ids.Contains(x.Id)).ToList();
            // Nếu sách đã bị xóa, bỏ mã cũ khỏi Session để số lượng giỏ chính xác.
            bool cartChanged = false;
            foreach (int id in ids)
            {
                if (!books.Any(book => book.Id == id))
                {
                    quantities.Remove(id);
                    cartChanged = true;
                }
            }

            if (cartChanged)
            {
                session["Cart"] = quantities;
                session.Remove("CheckoutToken");
            }

            var lines = new List<CartLine>();
            foreach (var book in books)
            {
                var line = new CartLine();
                line.Book = book;
                line.Quantity = quantities[book.Id];
                lines.Add(line);
            }

            return lines;
        }
    }
}
