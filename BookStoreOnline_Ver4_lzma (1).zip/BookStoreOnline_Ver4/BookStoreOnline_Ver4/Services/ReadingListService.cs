﻿using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BookStoreOnline.Services
{
    public class ReadingListService
    {
        readonly HttpSessionStateBase session;
        public ReadingListService(HttpSessionStateBase session)
        {
            this.session = session;
        }

        public List<int> Favorites
        {
            get
            {
                return session["Favorites"] as List<int> ?? new List<int>();
            }
        }

        public List<int> Recent
        {
            get
            {
                return session["Recent"] as List<int> ?? new List<int>();
            }
        }

        public bool Contains(int id)
        {
            return Favorites.Contains(id);
        }

        public void Toggle(int id)
        {
            var list = Favorites;
            if (!list.Remove(id))
            {
                list.Insert(0, id);
            }

            session["Favorites"] = list.Take(100).ToList();
        }

        public void Remember(int id)
        {
            var list = Recent;
            list.Remove(id);
            list.Insert(0, id);
            session["Recent"] = list.Take(12).ToList();
        }
    }
}
