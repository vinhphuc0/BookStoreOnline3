﻿using System;
using System.Security.Cryptography;

namespace BookStoreOnline.Services
{
    public static class Passwords
    {
        // Hàm hỗ trợ bảo mật: băm mật khẩu kèm salt, đọc được mật khẩu từ bản cũ.
        // Khi học luồng đăng nhập, chỉ cần hiểu hai hàm Hash và Verify. Không đổi sang lưu mật khẩu rõ.
        static byte[] Derive(string text, byte[] salt, int iterations, int prf)
        {
            using (var kdf = new Rfc2898DeriveBytes(text, salt, iterations, prf == 0 ? HashAlgorithmName.SHA1 : prf == 1 ? HashAlgorithmName.SHA256 : HashAlgorithmName.SHA512))
            {
                return kdf.GetBytes(32);
            }
        }

        static int Read(byte[] b, int i)
        {
            return (b[i] << 24) | (b[i + 1] << 16) | (b[i + 2] << 8) | b[i + 3];
        }

        static void Write(byte[] b, int i, int n)
        {
            b[i] = (byte)(n >> 24);
            b[i + 1] = (byte)(n >> 16);
            b[i + 2] = (byte)(n >> 8);
            b[i + 3] = (byte)n;
        }

        public static string Hash(string password)
        {
            var salt = new byte[16];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }

            var hash = Derive(password, salt, 100000, 2);
            var data = new byte[61];
            data[0] = 1;
            Write(data, 1, 2);
            Write(data, 5, 100000);
            Write(data, 9, 16);
            Buffer.BlockCopy(salt, 0, data, 13, 16);
            Buffer.BlockCopy(hash, 0, data, 29, 32);
            return Convert.ToBase64String(data);
        }

        public static bool Verify(string encoded, string password)
        {
            try
            {
                var b = Convert.FromBase64String(encoded);
                int offset, saltLength, iterations, prf;
                if (b.Length == 49 && b[0] == 0)
                {
                    offset = 1;
                    saltLength = 16;
                    iterations = 1000;
                    prf = 0;
                }
                else if (b.Length >= 61 && b[0] == 1)
                {
                    offset = 13;
                    prf = Read(b, 1);
                    iterations = Read(b, 5);
                    saltLength = Read(b, 9);
                    if (prf < 0 || prf > 2 || iterations < 1 || iterations > 1000000 || saltLength < 16 || saltLength > 128 || b.Length != offset + saltLength + 32)
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }

                var salt = new byte[saltLength];
                Buffer.BlockCopy(b, offset, salt, 0, saltLength);
                var hash = Derive(password, salt, iterations, prf);
                int diff = 0;
                for (int i = 0; i < 32; i++)
                {
                    diff |= hash[i] ^ b[offset + saltLength + i];
                }

                return diff == 0;
            }
            catch (FormatException)
            {
                return false;
            }
            catch (ArgumentException)
            {
                return false;
            }
        }
    }
}
