﻿using System;
using System.Linq;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Security;
using BookStoreOnline.Data;

namespace BookStoreOnline
{
    public class MvcApplication : HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            System.Data.Entity.Database.SetInitializer<BookStoreContext>(null);
        }

        // Lưu lỗi gốc để kiểm tra trên máy chạy; không thay đổi cách xử lý lỗi hiện tại.
        protected void Application_Error()
        {
            var error = Server.GetLastError();
            if (error == null) return;
            try
            {
                string log = Server.MapPath("~/App_Data/website-error.log");
                System.IO.File.AppendAllText(log, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")
                    + Environment.NewLine + error + Environment.NewLine + Environment.NewLine);
            }
            catch (System.IO.IOException) { /* Không làm phát sinh lỗi thứ hai khi ghi log. */ }
            catch (UnauthorizedAccessException) { /* Kiểm tra quyền ghi thư mục App_Data. */ }
        }

        // Cookie lưu Id. Mỗi request đọc lại Role/IsActive từ DB để khóa tài khoản có hiệu lực.
        protected void Application_PostAuthenticateRequest()
        {
            if (!Request.IsAuthenticated)
            {
                return;
            }

            int id;
            if (!int.TryParse(Context.User.Identity.Name, out id))
            {
                FormsAuthentication.SignOut();
                Context.User = new GenericPrincipal(new GenericIdentity(""), new string[0]);
                return;
            }

            using (var db = new BookStoreContext())
            {
                var user = db.Users.AsNoTracking().FirstOrDefault(x => x.Id == id && x.IsActive);
                if (user == null)
                {
                    FormsAuthentication.SignOut();
                    Context.User = new GenericPrincipal(new GenericIdentity(""), new string[0]);
                    return;
                }

                Context.Items["CurrentUser"] = user;
                var principal = new GenericPrincipal(new GenericIdentity(user.Email, "Forms"), new[] { user.Role });
                Context.User = principal;
                Thread.CurrentPrincipal = principal;
            }
        }
    }
}
