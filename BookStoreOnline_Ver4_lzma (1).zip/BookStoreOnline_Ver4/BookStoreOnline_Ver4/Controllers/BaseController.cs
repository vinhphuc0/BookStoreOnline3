﻿using System;
using System.Data.Entity;
using System.Linq;
using BookStoreOnline.ViewModels;
using System.Web.Mvc;
using BookStoreOnline.Data;
using BookStoreOnline.Models;
using BookStoreOnline.Services;

namespace BookStoreOnline.Controllers
{
    // Controller nhận yêu cầu, kiểm tra dữ liệu và trả View tương ứng.
    public abstract class BaseController : Controller
    {
        // Dùng chung kết nối EF6 cho các action của một request.
        protected readonly BookStoreContext db = new BookStoreContext();

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            base.OnActionExecuting(filterContext);
            if (!filterContext.IsChildAction && !filterContext.HttpContext.Request.IsAjaxRequest())
            {
                try
                {
                    ViewBag.MenuCategories = db.Categories.AsNoTracking()
                        .Where(c => db.Books.Any(b => b.CategoryId == c.Id && b.IsActive && b.Stock > 0))
                        .OrderBy(c => c.Id)
                        .ToList();
                }
                catch
                {
                    ViewBag.MenuCategories = new System.Collections.Generic.List<Category>();
                }
            }
        }
        protected User CurrentUser
        {
            get
            {
                return HttpContext.Items["CurrentUser"] as User;
            }
        }

        protected int UserId
        {
            get
            {
                return CurrentUser.Id;
            }
        }

        protected CartService Cart
        {
            get
            {
                return new CartService(Session, db);
            }
        }

        protected ReadingListService Reading
        {
            get
            {
                return new ReadingListService(Session);
            }
        }

        private OrderDatabaseStatus ReadOrderDatabaseStatus()
        {
            const string key = "OrderDatabaseStatus";
            var status = HttpContext.Items[key] as OrderDatabaseStatus;
            if (status == null)
            {
                const string sql = @"
                   SELECT COALESCE(CONVERT(nvarchar(128), SERVERPROPERTY('ServerName')), N'') AS ServerName,
                          DB_NAME() AS DatabaseName,
                          CAST(CASE WHEN COL_LENGTH(N'dbo.Orders', N'PaymentStatus') IS NULL
                               THEN 0 ELSE 1 END AS bit) AS HasPaymentStatus,
                          CAST(CASE WHEN EXISTS (
                              SELECT 1 FROM sys.check_constraints
                              WHERE parent_object_id = OBJECT_ID(N'dbo.Orders')
                                AND name = N'CK_Orders_Status_MVC5'
                                AND is_disabled = 0 AND is_not_trusted = 0)
                               THEN 1 ELSE 0 END AS bit) AS HasStatusRule,
                          CAST(CASE WHEN (SELECT COUNT(*) FROM sys.columns
                              WHERE object_id = OBJECT_ID(N'dbo.Orders')
                                AND name IN (N'Recipient', N'Address', N'Note')
                                AND max_length = -1 AND is_nullable = 0) = 3
                               THEN 1 ELSE 0 END AS bit) AS HasShippingText";
                status = db.Database.SqlQuery<OrderDatabaseStatus>(sql).Single();
                HttpContext.Items[key] = status;
            }

            return status;
        }

        protected bool OrderSchemaReady()
        {
            var status = ReadOrderDatabaseStatus();
            return status.HasPaymentStatus && status.HasStatusRule && status.HasShippingText;
        }

        protected ActionResult OrderSetupRequired()
        {
            Response.StatusCode = 503;
            Response.TrySkipIisCustomErrors = true;
            return View("~/Views/Shared/OrderDatabaseSetup.cshtml", ReadOrderDatabaseStatus());
        }

        // Lỗi ghi DB: ghi chi tiết vào log, thông báo ngắn và đọc lại dữ liệu đã lưu.
        protected ActionResult OrderWriteFailed(Exception error, string action, int? id, string message)
        {
            System.Diagnostics.Trace.TraceError(error.ToString());
            TempData["Error"] = message;
            return RedirectToAction(action, new { id = id });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }

            base.Dispose(disposing);
        }

        protected ActionResult Back(string url, string action = "Index", string controller = "Home")
        {
            if (Url.IsLocalUrl(url))
            {
                return Redirect(url);
            }

            return RedirectToAction(action, controller, new { area = "" });
        }
    }
}
