﻿using BookStoreOnline.Data;
using BookStoreOnline.Models;
using BookStoreOnline.Services;
using BookStoreOnline.ViewModels;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Data.Entity;

namespace BookStoreOnline.Controllers
{
    // Controller nhận yêu cầu, kiểm tra dữ liệu và trả View tương ứng.
    public class HomeController : BaseController
    {
        // Truy vấn chung: chỉ sách đang bán và còn tồn.
        private IQueryable<Book> ActiveBooks()
        {
            return db.Books.AsNoTracking().Include(x => x.Category).Include(x => x.Author).Include(x => x.Publisher).Where(x => x.IsActive && x.Stock > 0);
        }

        public ActionResult Index(string q, int? category, int? author, int? publisher, decimal? minPrice, decimal? maxPrice, bool hasSample = false, string sort = "new", int page = 1, string kind = "all")
        {
            // 1. Bỏ khoảng trắng, giới hạn độ dài từ khóa.
            if (string.IsNullOrWhiteSpace(q))
            {
                q = null;
            }
            else
            {
                q = q.Trim();
                if (q.Length > 120)
                {
                    q = q.Substring(0, 120);
                }
            }

            minPrice = minPrice.HasValue ? (decimal? )Math.Max(0, minPrice.Value) : null;
            maxPrice = maxPrice.HasValue ? (decimal? )Math.Max(0, maxPrice.Value) : null;
            if (minPrice > maxPrice)
            {
                decimal? temporary = minPrice;
                minPrice = maxPrice;
                maxPrice = temporary;
            }

            var books = ActiveBooks();
            if (!new[]
            {
                "all",
                "published",
                "demo"
            }.Contains(kind))
            {
                kind = "all";
            }

            if (kind == "published")
            {
                books = books.Where(x => x.SourceUrl != "");
            }

            if (kind == "demo")
            {
                books = books.Where(x => x.Isbn.StartsWith("DEMO-"));
            }

            if (q != null)
            {
                var ids = SearchIds(q);
                books = books.Where(x => ids.Contains(x.Id));
            }

            if (category.HasValue)
            {
                books = books.Where(x => x.CategoryId == category.Value);
            }

            if (author.HasValue)
            {
                books = books.Where(x => x.AuthorId == author.Value);
            }

            if (publisher.HasValue)
            {
                books = books.Where(x => x.PublisherId == publisher.Value);
            }

            if (minPrice.HasValue)
            {
                books = books.Where(x => x.Price >= minPrice.Value);
            }

            if (maxPrice.HasValue)
            {
                books = books.Where(x => x.Price <= maxPrice.Value);
            }

            if (hasSample)
            {
                books = books.Where(x => x.SampleText != "");
            }

            string[] sorts = new[]
            {
                "new",
                "price-asc",
                "price-desc",
                "title",
                "discount",
                "bestseller"
            };
            if (!sorts.Contains(sort))
            {
                sort = "new";
            }

            var sales = db.OrderItems.Where(x => x.Order.Status == "Đã giao");
            if (sort == "bestseller")
            {
                books = books.Where(book => sales.Any(x => x.BookId == book.Id));
            }

            var total = books.Count();
            int pageCount = (int)Math.Ceiling(total / 12.0);
            if (pageCount < 1)
            {
                pageCount = 1;
            }

            if (page < 1)
            {
                page = 1;
            }

            if (page > pageCount)
            {
                page = pageCount;
            }

            switch (sort)
            {
                case "price-asc":
                    books = books.OrderBy(x => x.Price).ThenBy(x => x.Id);
                    break;
                case "price-desc":
                    books = books.OrderByDescending(x => x.Price).ThenBy(x => x.Id);
                    break;
                case "title":
                    books = books.OrderBy(x => x.Title).ThenBy(x => x.Id);
                    break;
                case "discount":
                    books = books.OrderByDescending(x => (x.ListPrice - x.Price) / x.ListPrice).ThenBy(x => x.Id);
                    break;
                case "bestseller":
                    books = books.OrderByDescending(book => sales.Where(x => x.BookId == book.Id).Sum(x => (int? )x.Quantity) ?? 0).ThenBy(x => x.Id);
                    break;
                default:
                    books = books.OrderByDescending(x => x.CreatedAt).ThenByDescending(x => x.Id);
                    break;
            }

            var model = new CatalogModel
            {
                Books = books.Skip((page - 1) * 12).Take(12).ToList(),
                Total = total,
                Page = page,
                Q = q,
                Category = category,
                Author = author,
                Kind = kind,
                Publisher = publisher,
                MinPrice = minPrice,
                MaxPrice = maxPrice,
                HasSample = hasSample,
                Sort = sort,
                Categories = db.Categories.Where(c => db.Books.Any(b => b.CategoryId == c.Id && b.IsActive)).OrderBy(x => x.Id).ToList(),
                Authors = db.Authors.Where(a => db.Books.Any(b => b.AuthorId == a.Id && b.IsActive)).OrderBy(x => x.Name).ToList(),
                Publishers = db.Publishers.Where(p => db.Books.Any(b => b.PublisherId == p.Id && b.IsActive)).OrderBy(x => x.Name).ToList()
            };
            if (!model.IsFiltered && page == 1 && sort == "new")
            {
                model.NewBooks = ActiveBooks().Where(x => x.Stock > 0).OrderByDescending(x => x.SourceUrl != "").ThenByDescending(x => x.CreatedAt).ThenByDescending(x => x.Id).Take(4).ToList();
                // Dùng các thể loại thật đang có, không để kệ sách mẫu rỗng.
                foreach (var c in model.Categories.Take(6))
                {
                    var rows = ActiveBooks().Where(x => x.CategoryId == c.Id && x.Stock > 0).OrderByDescending(x => x.SourceUrl != "").ThenByDescending(x => x.CreatedAt).ThenByDescending(x => x.Id).Take(4).ToList();
                    if (rows.Count > 0)
                    {
                        model.ThemeShelves.Add(new HomeShelf {
                            CategoryId = c.Id,
                            Name = c.Name,
                            Books = rows
                        });
                    }
                }

                model.FeaturedAuthors = db.Authors.AsNoTracking().Where(a => db.Books.Any(book => book.AuthorId == a.Id && book.IsActive && book.SourceUrl != "")).Select(a => new CatalogSpotlight {
                    Id = a.Id,
                    Name = a.Name,
                    BookCount = db.Books.Count(book => book.AuthorId == a.Id && book.IsActive)
                }).Where(a => a.BookCount > 0).OrderByDescending(a => a.BookCount).ThenBy(a => a.Name).Take(6).ToList();
                model.BestSellers = ActiveBooks().Where(book => sales.Any(x => x.BookId == book.Id)).OrderByDescending(book => sales.Where(x => x.BookId == book.Id).Sum(x => (int? )x.Quantity) ?? 0).ThenBy(x => x.Id).Take(4).ToList();
                var ids = Reading.Recent;
                var recent = ActiveBooks().Where(book => ids.Contains(book.Id)).ToList();
                model.RecentBooks = ids.Select(id => recent.FirstOrDefault(x => x.Id == id)).OfType<Book>().Take(4).ToList();
            }

            return View(model);
        }

        private List<int> SearchIds(string q)
        {
            const string sql = @"SELECT b.Id
                FROM dbo.Books b
                JOIN dbo.Authors a ON b.AuthorId = a.Id
                WHERE b.IsActive = 1 AND b.Stock > 0
                  AND (CHARINDEX(@p0, b.Title COLLATE Latin1_General_100_CI_AI) > 0
                    OR CHARINDEX(@p0, a.Name COLLATE Latin1_General_100_CI_AI) > 0
                    OR CHARINDEX(@p0, b.Isbn) > 0)";
            return db.Database.SqlQuery<int>(sql, q).ToList();
        }

        [HttpGet]
        public ActionResult Suggest(string q)
        {
            q = q == null ? null : q.Trim();
            if (string.IsNullOrEmpty(q) || q.Length < 2 || q.Length > 120)
            {
                return Json(new object[0], JsonRequestBehavior.AllowGet);
            }

            var ids = SearchIds(q);
            return Json(db.Books.AsNoTracking().Where(book => ids.Contains(book.Id)).OrderBy(book => book.Title).Take(6).Select(book => new { title = book.Title }).ToList(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult Policy()
        {
            return View();
        }

        public ActionResult Support()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult Guide(string topic = "reading")
        {
            if (!new[]
            {
                "reading",
                "children",
                "notes"
            }.Contains(topic))
            {
                return HttpNotFound();
            }

            ViewBag.Topic = topic;
            return View();
        }

        public ActionResult Error()
        {
            return View();
        }

        public ActionResult Denied()
        {
            return new HttpStatusCodeResult(403, "Forbidden");
        }
    }
}
