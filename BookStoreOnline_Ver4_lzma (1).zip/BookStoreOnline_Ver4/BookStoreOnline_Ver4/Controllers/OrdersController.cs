﻿using System;
using System.Linq;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Web.Mvc;
using BookStoreOnline.Models;
using BookStoreOnline.ViewModels;
using BookStoreOnline.Services;

namespace BookStoreOnline.Controllers
{
    [Authorize]
    // Controller nhận yêu cầu, kiểm tra dữ liệu và trả View tương ứng.
    public class OrdersController : BaseController
    {
        public ActionResult Index()
        {
            if (!OrderSchemaReady())
            {
                return OrderSetupRequired();
            }

            return View(db.Orders.AsNoTracking().Include(x => x.OrderItems).Where(x => x.UserId == UserId).OrderByDescending(x => x.Id).ToList());
        }

        // Chỉ lấy đơn của người đang đăng nhập rồi chia nhóm theo trạng thái.
        public ActionResult MyOrder(string q, string status = "all", bool more = false)
        {
            if (!OrderSchemaReady())
            {
                return OrderSetupRequired();
            }

            // 1. Bỏ khoảng trắng, giới hạn độ dài từ khóa.
            if (string.IsNullOrWhiteSpace(q))
            {
                q = null;
            }
            else
            {
                q = q.Trim();
                if (q.Length > 120)
                {
                    q = q.Substring(0, 120);
                }
            }

            if (status != "all" && !OrderRules.Statuses.Contains(status))
            {
                status = "all";
            }

            var own = db.Orders.AsNoTracking().Where(x => x.UserId == UserId);
            var model = new MyOrdersModel
            {
                Q = q,
                Status = status,
                More = more,
                HasAnyOrders = own.Any()
            };
            foreach (var s in OrderRules.Statuses)
            {
                model.Counts[s] = own.Count(x => x.Status == s);
            }

            if (q != null)
            {
                int id;
                bool byId = OrderRules.TryId(q, out id);
                own = own.Where(x => (byId && x.Id == id) || x.OrderItems.Any(i => i.BookTitle.Contains(q)));
            }

            // Chọn tất cả nhóm, hoặc chỉ nhóm trạng thái khách đang xem.
            string[] selectedStatuses = OrderRules.Statuses;
            if (status != "all")
            {
                selectedStatuses = new string[]
                {
                    status
                };
            }

            foreach (string s in selectedStatuses)
            {
                var group = own.Where(x => x.Status == s);
                model.Groups.Add(new OrderGroup {
                    Status = s,
                    Total = group.Count(),
                    Orders = group.Include(x => x.OrderItems.Select(i => i.Book)).OrderByDescending(x => x.CreatedAt).ThenByDescending(x => x.Id).Take(more && status != "all" ? 50 : 2).ToList()
                });
            }

            return View(model);
        }

        public ActionResult Details(int id)
        {
            if (!OrderSchemaReady())
            {
                return OrderSetupRequired();
            }

            var order = db.Orders.AsNoTracking().Include(x => x.User).Include(x => x.OrderItems.Select(i => i.Book)).FirstOrDefault(x => x.Id == id && x.UserId == UserId);
            return order == null ? (ActionResult)HttpNotFound() : View(order);
        }

        [HttpGet]
        public ActionResult Checkout()
        {
            if (!OrderSchemaReady())
            {
                return OrderSetupRequired();
            }

            var lines = Cart.Lines();
            if (lines.Count == 0)
            {
                return RedirectToAction("Index", "Cart");
            }

            string token = Session["CheckoutToken"] as string;
            if (string.IsNullOrEmpty(token))
            {
                token = Guid.NewGuid().ToString("N");
                Session["CheckoutToken"] = token;
            }
            ViewBag.Lines = lines;
            var last = db.Orders.Where(x => x.UserId == UserId).OrderByDescending(x => x.Id).FirstOrDefault();
            ViewBag.AddressPrefilled = last != null;
            return View(new CheckoutForm {
                Token = token,
                Recipient = last == null ? CurrentUser.FullName : last.Recipient,
                Phone = last == null ? "" : last.Phone,
                Address = last == null ? "" : last.Address
            });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Checkout(CheckoutForm form)
        {
            if (!OrderSchemaReady())
            {
                return OrderSetupRequired();
            }

            var lines = Cart.Lines();
            if (lines.Count == 0)
            {
                TempData["Error"] = "Giỏ hàng đang trống. Hãy chọn sách trước khi đặt hàng.";
                return RedirectToAction("Index", "Cart");
            }
            ViewBag.Lines = lines;

            // Trình duyệt gửi xuống dòng CRLF; tính một lần xuống dòng là một ký tự.
            form.NormalizeLineBreaks();
            ModelState.Clear();
            TryValidateModel(form);
            if (!ModelState.IsValid)
            {
                return View(form);
            }

            if (form.Token != (Session["CheckoutToken"] as string))
            {
                // Giữ thông tin đã nhập, hiện lại giỏ mới để khách kiểm tra rồi xác nhận.
                string token = Session["CheckoutToken"] as string;
                if (string.IsNullOrEmpty(token))
                {
                    token = Guid.NewGuid().ToString("N");
                    Session["CheckoutToken"] = token;
                }
                form.Token = token;
                ModelState.Remove("Token");
                ModelState.AddModelError("", "Giỏ hàng hoặc phiên đặt hàng đã thay đổi. Thông tin nhận sách vẫn được giữ; kiểm tra lại số lượng và tổng tiền rồi bấm đặt hàng.");
                return View(form);
            }

            // Giỏ chỉ giữ Id và số lượng. Giá phải đọc lại từ database.
            var quantities = Cart.Get();
            if (quantities.Count == 0)
            {
                return RedirectToAction("Index", "Cart");
            }

            // Lưu đơn và trừ kho cùng một giao dịch; lỗi thì không lưu dở dang.
            try
            {
                using (var transaction = db.Database.BeginTransaction(IsolationLevel.Serializable))
                {
                    var ids = quantities.Keys.ToList();
                    var books = db.Books.Where(x => ids.Contains(x.Id)).ToList();
                    if (books.Count != ids.Count || books.Any(x => !x.IsActive || quantities[x.Id] < 1 || quantities[x.Id] > 20 || x.Stock < quantities[x.Id]))
                    {
                        ModelState.AddModelError("", "Một số sách hết hàng hoặc số lượng không hợp lệ. Hãy cập nhật giỏ.");
                        return View(form);
                    }

                    decimal sub = books.Sum(x => x.Price * quantities[x.Id]);
                    var order = new Order
                    {
                        CheckoutKey = form.Token,
                        UserId = UserId,
                        Recipient = form.Recipient.Trim(),
                        Phone = form.Phone,
                        Address = form.Address.Trim(),
                        Note = form.Note ?? "",
                        ShippingFee = sub >= 300000 ? 0 : 30000,
                        Status = "Đang xử lý",
                        PaymentStatus = "Chờ thanh toán",
                        PaymentMethod = "COD"
                    };
                    order.Total = sub + order.ShippingFee;
                    foreach (var book in books)
                    {
                        order.OrderItems.Add(new OrderItem {
                            BookId = book.Id,
                            BookTitle = book.Title,
                            Quantity = quantities[book.Id],
                            UnitPrice = book.Price
                        });
                        book.Stock -= quantities[book.Id];
                    }

                    db.Orders.Add(order);
                    try
                    {
                        db.SaveChanges();
                        transaction.Commit();
                    }
                    catch (DbUpdateException)
                    {
                        transaction.Rollback();
                        using (var lookup = new BookStoreOnline.Data.BookStoreContext())
                        {
                            var existing = lookup.Orders.AsNoTracking().FirstOrDefault(x => x.CheckoutKey == form.Token && x.UserId == UserId);
                            if (existing == null)
                            {
                                throw;
                            }

                            Cart.Clear();
                            Session.Remove("CheckoutToken");
                            return RedirectToAction("Details", new { id = existing.Id });
                        }
                    }

                    Cart.Clear();
                    Session.Remove("CheckoutToken");
                    TempData["Success"] = "Đặt hàng thành công. Bạn thanh toán khi nhận sách.";
                    return RedirectToAction("Details", new { id = order.Id });
                }
            }
            catch (System.Data.Entity.Infrastructure.DbUpdateException error)
            {
                return OrderWriteFailed(error, "MyOrder", null, "Chưa xác nhận được kết quả đặt hàng. Kiểm tra lịch sử đơn hàng trước khi đặt lại.");
            }
            catch (System.Data.Entity.Core.EntityException error)
            {
                return OrderWriteFailed(error, "MyOrder", null, "Chưa xác nhận được kết quả đặt hàng. Kiểm tra lịch sử đơn hàng trước khi đặt lại.");
            }
            catch (System.Data.SqlClient.SqlException error)
            {
                return OrderWriteFailed(error, "MyOrder", null, "Chưa xác nhận được kết quả đặt hàng. Kiểm tra lịch sử đơn hàng trước khi đặt lại.");
            }
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Cancel(int id)
        {
            if (!OrderSchemaReady())
            {
                return OrderSetupRequired();
            }

            // Cùng transaction với hoàn kho; gửi lại form không hoàn kho lần hai.
            try
            {
                using (var transaction = db.Database.BeginTransaction(IsolationLevel.Serializable))
                {
                    var order = db.Orders.Include(x => x.OrderItems).FirstOrDefault(x => x.Id == id && x.UserId == UserId);
                    if (order == null)
                    {
                        return HttpNotFound();
                    }

                    if (!OrderRules.CanCustomerCancel(order.Status, order.PaymentStatus))
                    {
                        TempData["Error"] = "Chỉ có thể hủy đơn chưa thanh toán đang xử lý.";
                        return RedirectToAction("Details", new { id = id });
                    }

                    var bookIds = order.OrderItems.Select(x => x.BookId).ToList();
                    var books = db.Books.Where(x => bookIds.Contains(x.Id)).ToList();
                    foreach (var item in order.OrderItems)
                    {
                        var book = books.FirstOrDefault(x => x.Id == item.BookId);
                        if (book == null)
                        {
                            TempData["Error"] = "Chưa thể hoàn kho. Vui lòng liên hệ nhà sách.";
                            return RedirectToAction("Details", new { id = id });
                        }

                        book.Stock += item.Quantity;
                    }

                    order.Status = "Đã hủy";
                    db.SaveChanges();
                    transaction.Commit();
                }

                TempData["Success"] = "Đã hủy đơn hàng và hoàn lại số lượng vào kho.";
                return RedirectToAction("Details", new { id = id });
            }
            catch (System.Data.Entity.Infrastructure.DbUpdateException error)
            {
                return OrderWriteFailed(error, "Details", id, "Chưa xác nhận được việc hủy đơn. Hãy kiểm tra trạng thái hiện tại rồi thử lại.");
            }
            catch (System.Data.Entity.Core.EntityException error)
            {
                return OrderWriteFailed(error, "Details", id, "Chưa xác nhận được việc hủy đơn. Hãy kiểm tra trạng thái hiện tại rồi thử lại.");
            }
            catch (System.Data.SqlClient.SqlException error)
            {
                return OrderWriteFailed(error, "Details", id, "Chưa xác nhận được việc hủy đơn. Hãy kiểm tra trạng thái hiện tại rồi thử lại.");
            }
        }

        [HttpPost, ValidateAntiForgeryToken]
        // Mỗi đầu sách thêm một cuốn, vẫn kiểm tra tồn kho hiện tại.
        public ActionResult Reorder(int id)
        {
            if (!OrderSchemaReady())
            {
                return OrderSetupRequired();
            }

            var order = db.Orders.AsNoTracking().Include(x => x.OrderItems).FirstOrDefault(x => x.Id == id && x.UserId == UserId);
            if (order == null)
            {
                return HttpNotFound();
            }

            // Không chỉ ẩn nút: chặn cả yêu cầu POST tự gửi cho đơn chưa giao.
            if (order.Status != "Đã giao")
            {
                TempData["Error"] = "Chỉ được mua lại đơn đã giao thành công.";
                return RedirectToAction("Details", new { id = id });
            }

            int added = 0, skipped = 0;
            foreach (int bookId in order.OrderItems.Select(x => x.BookId).Distinct())
            {
                var book = db.Books.Find(bookId);
                var cart = Cart.Get();
                int current = cart.ContainsKey(bookId) ? cart[bookId] : 0;
                if (book == null || !book.IsActive || current >= book.Stock || current >= 20)
                {
                    skipped++;
                    continue;
                }

                Cart.Set(bookId, current + 1);
                added++;
            }

            TempData[added > 0 ? "Success" : "Error"] = "Đã thêm " + added + " đầu sách, mỗi đầu sách 1 cuốn vào giỏ." + (skipped > 0 ? " " + skipped + " đầu sách không thể thêm do hết hàng hoặc đạt giới hạn." : "");
            return RedirectToAction("Index", "Cart");
        }
    }
}
