﻿using System;
using System.Linq;
using System.Data.Entity;
using System.Web.Mvc;

namespace BookStoreOnline.Controllers
{
    // Controller nhận yêu cầu, kiểm tra dữ liệu và trả View tương ứng.
    public class CartController : BaseController
    {
        public ActionResult Index()
        {
            PrepareRecommendations();
            return View(Cart.Lines());
        }

        // Chỉ trả phần giỏ: danh sách, tổng tiền và sách gợi ý đều lấy lại từ DB.
        [HttpGet, OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        public ActionResult Contents()
        {
            PrepareRecommendations();
            return PartialView("_CartContents", Cart.Lines());
        }

        private void PrepareRecommendations()
        {
            var lines = Cart.Lines();
            var ids = lines.Select(x => x.Book.Id).ToList();
            ViewBag.Recommended = db.Books.AsNoTracking()
                .Include(x => x.Author)
                .Include(x => x.Category)
                .Include(x => x.Publisher)
                .Where(x => x.IsActive && x.Stock > 0 && !ids.Contains(x.Id))
                .OrderByDescending(x => x.SourceUrl != "")
                .ThenBy(x => x.Price)
                .ThenByDescending(x => x.Id)
                .Take(4)
                .ToList();
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Add(int id, int quantity = 1, string proceed = null, string returnUrl = null)
        {
            if (!ModelState.IsValid)
            {
                return CartError("Số lượng phải là số nguyên hợp lệ.");
            }

            var book = db.Books.Find(id);
            if (book == null || !book.IsActive)
            {
                return CartError("Sách không còn được bán.");
            }

            var items = Cart.Get();
            int current = items.ContainsKey(id) ? items[id] : 0;
            int maxAllowed = Math.Min(20, book.Stock);
            int canAdd = maxAllowed - current;
            if (quantity < 1)
            {
                return CartError("Số lượng phải từ 1 trở lên.");
            }

            if (canAdd <= 0)
            {
                return CartError(string.Format("Trong giỏ hàng đã có đủ {0} cuốn (tối đa có thể đặt cho sách này).", current));
            }

            if (quantity > canAdd)
            {
                if (current > 0)
                {
                    return CartError(string.Format("Trong giỏ đã có {0} cuốn; bạn chỉ có thể thêm tối đa {1} cuốn nữa (tồn kho: {2}).", current, canAdd, book.Stock));
                }

                return CartError(string.Format("Số lượng vượt giới hạn cho phép (tối đa {0} cuốn).", maxAllowed));
            }

            Cart.Set(id, current + quantity);
            if (Request.IsAjaxRequest())
            {
                return Json(new { success = true, message = "Đã thêm vào giỏ hàng.", cartCount = Cart.Count });
            }

            TempData["Success"] = "Đã thêm sách vào giỏ hàng.";
            if (proceed == "checkout")
            {
                return RedirectToAction("Checkout", "Orders");
            }

            return Back(returnUrl, "Index", "Home");
        }

        private ActionResult CartError(string message)
        {
            if (Request.IsAjaxRequest())
            {
                return Json(new { success = false, message = message });
            }

            TempData["Error"] = message;
            return RedirectToAction("Index");
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Update(int id, int quantity)
        {
            if (!ModelState.IsValid)
            {
                return CartError("Số lượng phải là số nguyên hợp lệ.");
            }

            if (quantity < 0)
            {
                TempData["Error"] = "Số lượng không được âm.";
                return RedirectToAction("Index");
            }

            var book = db.Books.Find(id);
            if (quantity > 0 && (book == null || !book.IsActive || quantity > book.Stock || quantity > 20))
            {
                TempData["Error"] = "Số lượng không hợp lệ hoặc sách hết hàng.";
            }
            else
            {
                Cart.Set(id, quantity);
            }

            return RedirectToAction("Index");
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Clear()
        {
            Cart.Clear();
            TempData["Success"] = "Đã xóa sách trong giỏ hàng.";
            return RedirectToAction("Index");
        }
    }
}
