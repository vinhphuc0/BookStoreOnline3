﻿using System;
using System.Linq;
using System.Data.Entity;
using System.Web.Mvc;
using BookStoreOnline.Models;
using BookStoreOnline.ViewModels;

namespace BookStoreOnline.Controllers
{
    // Controller nhận yêu cầu, kiểm tra dữ liệu và trả View tương ứng.
    public class BooksController : BaseController
    {
        IQueryable<Book> Active()
        {
            return db.Books.AsNoTracking().Include(x => x.Category).Include(x => x.Author).Include(x => x.Publisher).Where(x => x.IsActive);
        }

        public ActionResult Details(int id)
        {
            var book = Active().FirstOrDefault(x => x.Id == id);
            if (book == null)
            {
                return HttpNotFound();
            }

            Reading.Remember(id);
            return View(new BookDetailsModel {
                Book = book,
                Related = Active().Where(x => x.Id != id && x.CategoryId == book.CategoryId).OrderByDescending(x => x.Stock > 0).ThenByDescending(x => x.CreatedAt).ThenByDescending(x => x.Id).Take(4).ToList(),
                Sold = db.OrderItems.Where(x => x.BookId == id && x.Order.Status == "Đã giao").Sum(x => (int? )x.Quantity) ?? 0
            });
        }

        public ActionResult Sample(int id, int page = 1)
        {
            var book = Active().FirstOrDefault(x => x.Id == id);
            if (book == null)
            {
                return HttpNotFound();
            }

            // PDF đọc thử được NXB công bố; chỉ nhận hai máy chủ lưu trữ nguồn.
            if (book.SampleText.StartsWith("PDF:", StringComparison.Ordinal))
            {
                Uri preview;
                if (!Uri.TryCreate(book.SampleText.Substring(4), UriKind.Absolute, out preview) || preview.Scheme != "https" || (preview.Host != "bizweb.dktcdn.net" && preview.Host != "file.hstatic.net"))
                {
                    return HttpNotFound();
                }

                ViewBag.PreviewUrl = preview.AbsoluteUri;
                return View("OfficialSample", book);
            }

            var pages = book.SampleText.Replace("\r\n", "\n").Split(new[] { "\n---PAGE---\n" }, StringSplitOptions.RemoveEmptyEntries).Where(x => !string.IsNullOrWhiteSpace(x)).ToArray();
            if (pages.Length == 0)
            {
                TempData["Error"] = "Cuốn sách này chưa có trang đọc thử. Bạn có thể xem giới thiệu và thông tin sách.";
                return RedirectToAction("Details", new { id });
            }

            page = Math.Max(1, Math.Min(page, pages.Length));
            ViewBag.Page = page;
            ViewBag.PageCount = pages.Length;
            ViewBag.Text = pages[page - 1];
            return View(book);
        }

        public ActionResult Favorites()
        {
            return List(Reading.Favorites, "Tủ sách yêu thích", "Lưu lại những cuốn sách bạn muốn đọc. Danh sách lưu trong phiên trình duyệt hiện tại.");
        }

        public ActionResult Recent()
        {
            return List(Reading.Recent, "Sách bạn vừa xem", "12 cuốn sách được xem gần đây trong phiên trình duyệt hiện tại.");
        }

        ActionResult List(System.Collections.Generic.List<int> ids, string title, string description)
        {
            var books = Active().Where(x => ids.Contains(x.Id)).ToList();
            return View("ReadingList", new ReadingListModel {
                Title = title,
                Description = description,
                Books = ids.Select(id => books.FirstOrDefault(x => x.Id == id)).OfType<Book>().ToList()
            });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult ToggleFavorite(int id, string returnUrl)
        {
            if (!db.Books.Any(x => x.Id == id && x.IsActive))
            {
                if (Request.IsAjaxRequest())
                {
                    return Json(new { success = false, message = "Sách không còn được bán." });
                }

                return HttpNotFound();
            }

            Reading.Toggle(id);
            bool isFavorite = Reading.Contains(id);
            string message = isFavorite ? "Đã thêm vào yêu thích." : "Đã bỏ khỏi yêu thích.";
            if (Request.IsAjaxRequest())
            {
                return Json(new { success = true, message = message, id = id, isFavorite = isFavorite, favoriteCount = Reading.Favorites.Count });
            }

            TempData["Success"] = message;
            return Back(returnUrl, "Favorites", "Books");
        }
    }
}
