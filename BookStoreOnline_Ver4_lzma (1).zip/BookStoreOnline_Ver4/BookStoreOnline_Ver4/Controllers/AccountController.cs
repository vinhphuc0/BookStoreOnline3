﻿using System;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Data.Entity.Infrastructure;
using BookStoreOnline.Models;
using BookStoreOnline.ViewModels;
using BookStoreOnline.Services;

namespace BookStoreOnline.Controllers
{
    // Controller nhận yêu cầu, kiểm tra dữ liệu và trả View tương ứng.
    public class AccountController : BaseController
    {
        [HttpGet]
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View(new LoginForm());
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Login(LoginForm form, string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            if (!ModelState.IsValid)
            {
                return View(form);
            }

            string email = form.Email.Trim().ToLowerInvariant();
            var user = db.Users.SingleOrDefault(x => x.Email == email);
            if (user == null || !user.IsActive || !Passwords.Verify(user.PasswordHash, form.Password))
            {
                ModelState.AddModelError("", "Email hoặc mật khẩu không đúng, hoặc tài khoản đã bị khóa.");
                return View(form);
            }

            SignIn(user);
            // Chỉ quay lại đường dẫn bên trong website, tránh chuyển sang trang ngoài.
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }

            if (user.Role == "Admin")
            {
                return RedirectToAction("Index", "Home", new { area = "Admin" });
            }

            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public ActionResult Register(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View(new RegisterForm());
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Register(RegisterForm form, string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            // Không tự bỏ khoảng trắng đầu để đăng ký thành công; yêu cầu sửa lại.
            if (!string.IsNullOrEmpty(form.FullName) && char.IsWhiteSpace(form.FullName[0]))
            {
                ModelState.AddModelError("FullName", "Họ tên không được có khoảng trắng ở đầu.");
            }

            if (!string.IsNullOrEmpty(form.Email) && char.IsWhiteSpace(form.Email[0]))
            {
                ModelState.AddModelError("Email", "Email không được có khoảng trắng ở đầu.");
            }

            if (!string.IsNullOrEmpty(form.NewPassword) && char.IsWhiteSpace(form.NewPassword[0]))
            {
                ModelState.AddModelError("NewPassword", "Mật khẩu không được có khoảng trắng ở đầu.");
            }

            if (!ModelState.IsValid)
            {
                return View(form);
            }

            string email = form.Email.Trim().ToLowerInvariant();
            if (db.Users.Any(x => x.Email == email))
            {
                ModelState.AddModelError("Email", "Email đã được đăng ký.");
                return View(form);
            }

            // Người dùng tự đăng ký luôn là Customer; không lấy Role từ form.
            var user = new User
            {
                FullName = form.FullName.Trim(),
                Email = email,
                PasswordHash = Passwords.Hash(form.NewPassword),
                Role = "Customer"
            };
            db.Users.Add(user);
            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                ModelState.AddModelError("", "Chưa thể tạo tài khoản. Kiểm tra email trùng rồi thử lại.");
                return View(form);
            }

            // Checklist yêu cầu đăng ký xong chuyển về trang đăng nhập.
            TempData["Success"] = "Đăng ký thành công. Bạn hãy đăng nhập để tiếp tục.";
            return RedirectToAction("Login", new { returnUrl });
        }

        [Authorize, HttpGet]
        [ActionName("Profile")]
        public ActionResult UserProfile()
        {
            return View(new ProfileForm {
                FullName = CurrentUser.FullName,
                Email = CurrentUser.Email
            });
        }

        [Authorize, HttpPost, ValidateAntiForgeryToken]
        [ActionName("Profile")]
        public ActionResult UserProfile(ProfileForm form)
        {
            if (!ModelState.IsValid)
            {
                return View(form);
            }

            string email = form.Email.Trim().ToLowerInvariant();
            if (db.Users.Any(x => x.Email == email && x.Id != UserId))
            {
                ModelState.AddModelError("Email", "Email đã được sử dụng.");
                return View(form);
            }

            // Id lấy từ phiên đăng nhập, không cho sửa hồ sơ người khác bằng Id trên URL.
            var user = db.Users.Find(UserId);
            user.FullName = form.FullName.Trim();
            user.Email = email;
            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                ModelState.AddModelError("", "Không lưu được hồ sơ. Kiểm tra email rồi thử lại.");
                return View(form);
            }

            TempData["Success"] = "Đã lưu hồ sơ.";
            return RedirectToAction("Profile");
        }

        public ActionResult AccessDenied()
        {
            Response.StatusCode = 403;
            Response.TrySkipIisCustomErrors = true;
            return View();
        }

        private void SignIn(User user)
        {
            // Cookie lưu mã người dùng được mã hóa; quyền được đọc lại từ DB mỗi request.
            var ticket = new FormsAuthenticationTicket(1, user.Id.ToString(), DateTime.Now, DateTime.Now.AddHours(8), false, "", FormsAuthentication.FormsCookiePath);
            var cookie = new HttpCookie(FormsAuthentication.FormsCookieName, FormsAuthentication.Encrypt(ticket))
            {
                HttpOnly = true,
                Secure = Request.IsSecureConnection,
                SameSite = SameSiteMode.Lax
            };
            Response.Cookies.Add(cookie);
        }

        [Authorize, HttpPost, ValidateAntiForgeryToken]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session.Clear();
            return RedirectToAction("Index", "Home");
        }
    }
}
