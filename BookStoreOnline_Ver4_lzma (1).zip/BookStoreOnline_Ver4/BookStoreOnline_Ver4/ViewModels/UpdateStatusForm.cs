﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class UpdateStatusForm
    {
        public int Id { get; set; }

        [Required]
        public string Status { get; set; }
        public string OriginalStatus { get; set; }
    }
}
