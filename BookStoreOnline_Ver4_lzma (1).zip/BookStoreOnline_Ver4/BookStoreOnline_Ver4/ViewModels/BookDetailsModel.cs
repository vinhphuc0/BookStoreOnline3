﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Thông tin chi tiết một sách và sách liên quan.
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class BookDetailsModel
    {
        public Book Book { get; set; }
        public List<Book> Related { get; set; } = new List<Book>();
        public int Sold { get; set; }
    }
}
