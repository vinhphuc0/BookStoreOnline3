﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Dữ liệu và điều kiện kiểm tra form đăng nhập.
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class LoginForm
    {
        [Required(ErrorMessage = "Vui lòng nhập email."), EmailAddress(ErrorMessage = "Email chưa đúng định dạng.")]
        [StringLength(254)]
        public string Email { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng nhập mật khẩu."), DataType(DataType.Password)]
        public string Password { get; set; } = "";
    }
}
