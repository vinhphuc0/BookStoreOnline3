﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class InventoryModel
    {
        public List<Book> InStock { get; set; }
        public List<Book> OutOfStock { get; set; }
    }
}
