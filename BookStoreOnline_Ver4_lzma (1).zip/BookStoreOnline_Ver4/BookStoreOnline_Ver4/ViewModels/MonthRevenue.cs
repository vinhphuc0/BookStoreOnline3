﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class MonthRevenue
    {
        public int Year { get; set; }
        public int Month { get; set; }
        public int Orders { get; set; }
        public decimal Revenue { get; set; }
    }
}
