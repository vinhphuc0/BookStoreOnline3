﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // ViewModel kiểm tra dữ liệu nhập, không bị ghi đè khi cập nhật EDMX.
    // Form dùng chung cho thể loại, tác giả và nhà xuất bản.
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class LookupForm
    {
        public int Id { get; set; }
        public string Kind { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập tên.")]
        [StringLength(100, ErrorMessage = "Tên tối đa 100 ký tự.")]
        public string Name { get; set; }
    }
}
