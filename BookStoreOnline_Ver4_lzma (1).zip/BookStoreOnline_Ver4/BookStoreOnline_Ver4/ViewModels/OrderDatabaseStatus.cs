﻿namespace BookStoreOnline.ViewModels
{
    // Chi hien ten server/database, khong hien chuoi ket noi hoac mat khau.
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class OrderDatabaseStatus
    {
        public string ServerName { get; set; }
        public string DatabaseName { get; set; }
        public bool HasShippingText { get; set; }
        public bool HasPaymentStatus { get; set; }
        public bool HasStatusRule { get; set; }
    }
}
