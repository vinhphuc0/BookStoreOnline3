﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Dữ liệu hiển thị trang chủ, bộ lọc và phân trang.
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class CatalogModel
    {
        public string Kind { get; set; } = "all";
        public List<Book> NewBooks { get; set; } = new List<Book>();
        public List<HomeShelf> ThemeShelves { get; set; } = new List<HomeShelf>();
        public List<CatalogSpotlight> FeaturedAuthors { get; set; } = new List<CatalogSpotlight>();
        public decimal? MinPrice { get; set; }
        public bool HasSample { get; set; }

        public bool IsFiltered
        {
            get
            {
                return Kind != "all" || Q != null || Category != null || Author != null || Publisher != null || MinPrice != null || MaxPrice != null || HasSample;
            }
        }

        public List<Book> BestSellers { get; set; } = new List<Book>();
        public List<Book> RecentBooks { get; set; } = new List<Book>();
        public List<Book> Books { get; set; } = new List<Book>();
        public List<Category> Categories { get; set; } = new List<Category>();
        public List<Author> Authors { get; set; } = new List<Author>();
        public List<Publisher> Publishers { get; set; } = new List<Publisher>();
        public string Q { get; set; }
        public int? Category { get; set; }
        public int? Author { get; set; }
        public int? Publisher { get; set; }
        public decimal? MaxPrice { get; set; }
        public string Sort { get; set; } = "new";
        public int Page { get; set; } = 1;
        public int Total { get; set; }

        public int PageCount
        {
            get
            {
                return (int)Math.Ceiling(Total / 12.0);
            }
        }
    }
}
