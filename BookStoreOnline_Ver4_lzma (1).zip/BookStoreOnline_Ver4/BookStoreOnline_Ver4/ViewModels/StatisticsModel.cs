﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class StatisticsModel
    {
        public int BookCount { get; set; }
        public int UserCount { get; set; }
        public Dictionary<string, int> Counts { get; set; } = new Dictionary<string, int>();
        public decimal Revenue { get; set; }
        public List<MonthRevenue> Months { get; set; } = new List<MonthRevenue>();
    }
}
