﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class AdminDashboard
    {
        public int BookCount { get; set; }
        public int UserCount { get; set; }
        public int Pending { get; set; }
        public decimal Revenue { get; set; }
        public List<Order> Orders { get; set; } = new List<Order>();
    }
}
