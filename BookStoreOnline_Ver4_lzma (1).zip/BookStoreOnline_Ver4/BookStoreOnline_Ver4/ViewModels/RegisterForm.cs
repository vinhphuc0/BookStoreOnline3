﻿using System.ComponentModel.DataAnnotations;

namespace BookStoreOnline.ViewModels
{
    // Chỉ nhận thông tin khách hàng; không nhận Role từ form.
    public class RegisterForm
    {
        [Required(ErrorMessage = "Vui lòng nhập email.")]
        [EmailAddress(ErrorMessage = "Email chưa đúng định dạng.")]
        [StringLength(50, ErrorMessage = "Email tối đa 50 ký tự.")]
        public string Email { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng nhập họ tên.")]
        [StringLength(50, MinimumLength = 2, ErrorMessage = "Họ tên cần từ 2 đến 50 ký tự.")]
        public string FullName { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng tạo mật khẩu.")]
        [StringLength(20, MinimumLength = 8, ErrorMessage = "Mật khẩu cần từ 8 đến 20 ký tự.")]
        [DataType(DataType.Password)]
        public string NewPassword { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng nhập lại mật khẩu.")]
        [StringLength(20, ErrorMessage = "Mật khẩu tối đa 20 ký tự.")]
        [Compare(nameof(NewPassword), ErrorMessage = "Hai mật khẩu chưa giống nhau.")]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; } = "";
    }
}
