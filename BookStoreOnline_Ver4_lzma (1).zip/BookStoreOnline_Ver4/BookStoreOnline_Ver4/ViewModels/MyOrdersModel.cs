﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class MyOrdersModel
    {
        public string Q { get; set; }
        public string Status { get; set; }
        public bool More { get; set; }
        public List<OrderGroup> Groups { get; set; } = new List<OrderGroup>();
        public Dictionary<string, int> Counts { get; set; } = new Dictionary<string, int>();
        public bool HasAnyOrders { get; set; }
    }
}
