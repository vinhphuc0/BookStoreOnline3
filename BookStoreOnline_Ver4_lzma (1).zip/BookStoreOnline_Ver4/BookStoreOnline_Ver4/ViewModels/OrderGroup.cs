﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class OrderGroup
    {
        public string Status { get; set; }
        public int Total { get; set; }
        public List<Order> Orders { get; set; } = new List<Order>();
    }
}
