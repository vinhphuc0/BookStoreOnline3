﻿using System.ComponentModel.DataAnnotations;

namespace BookStoreOnline.ViewModels
{
    // Kiểm tra ở server, kể cả khi trình duyệt tắt JavaScript.
    public class CheckoutForm
    {
        [Required(ErrorMessage = "Vui lòng nhập tên người nhận.")]
        [StringLength(100, ErrorMessage = "Tên người nhận tối đa 100 ký tự.")]
        public string Recipient { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng nhập số điện thoại.")]
        [RegularExpression(@"^0[0-9]{9}$", ErrorMessage = "Số điện thoại gồm 10 chữ số, bắt đầu bằng 0.")]
        public string Phone { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng nhập địa chỉ nhận sách.")]
        [StringLength(200, ErrorMessage = "Địa chỉ nhận sách tối đa 200 ký tự.")]
        public string Address { get; set; } = "";

        [StringLength(200, ErrorMessage = "Ghi chú giao hàng tối đa 200 ký tự.")]
        [DisplayFormat(ConvertEmptyStringToNull = false)]
        public string Note { get; set; } = "";

        [Required(ErrorMessage = "Phiên đặt hàng chưa hợp lệ. Hãy mở lại giỏ hàng.")]
        public string Token { get; set; } = "";

        // Đồng bộ cách đếm ký tự giữa textarea JavaScript và server Windows.
        public void NormalizeLineBreaks()
        {
            Address = (Address ?? "").Replace("\r\n", "\n").Replace("\r", "\n");
            Note = (Note ?? "").Replace("\r\n", "\n").Replace("\r", "\n");
        }

    }
}
