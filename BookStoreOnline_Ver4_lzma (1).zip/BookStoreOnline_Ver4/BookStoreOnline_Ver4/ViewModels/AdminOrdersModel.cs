﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class AdminOrdersModel
    {
        public List<Order> Orders { get; set; } = new List<Order>();
        public string Q { get; set; }
        public string Status { get; set; }
        public string Payment { get; set; }
        public DateTime? From { get; set; }
        public DateTime? To { get; set; }
        public string Sort { get; set; }
        public int Page { get; set; }
        public int Total { get; set; }

        public int Pages
        {
            get
            {
                return Math.Max(1, (int)Math.Ceiling(Total / 15.0));
            }
        }
    }
}
