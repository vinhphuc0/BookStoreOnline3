﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class LookupListModel
    {
        public string Kind { get; set; }
        public string Title { get; set; }
        public List<LookupRow> Rows { get; set; }
    }
}
