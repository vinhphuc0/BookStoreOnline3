﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Form quản trị viên; mật khẩu mới chỉ bắt buộc khi tạo tài khoản.
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class AdminUserForm
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập họ tên.")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Họ tên từ 2 đến 100 ký tự.")]
        public string FullName { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập email.")]
        [StringLength(254)]
        [EmailAddress(ErrorMessage = "Email chưa đúng định dạng.")]
        public string Email { get; set; }

        [StringLength(100, MinimumLength = 8, ErrorMessage = "Mật khẩu từ 8 đến 100 ký tự.")]
        [DataType(DataType.Password)]
        public string NewPassword { get; set; }
        public bool IsActive { get; set; } = true;
    }
}
