﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class LookupRow
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int BookCount { get; set; }
    }
}
