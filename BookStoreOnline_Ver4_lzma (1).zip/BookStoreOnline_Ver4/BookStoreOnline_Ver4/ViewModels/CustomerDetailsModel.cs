﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class CustomerDetailsModel
    {
        public User Customer { get; set; }
        public List<Order> Orders { get; set; }
    }
}
