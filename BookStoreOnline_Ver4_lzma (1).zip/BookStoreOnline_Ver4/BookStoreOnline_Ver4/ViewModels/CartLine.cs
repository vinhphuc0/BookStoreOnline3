﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class CartLine
    {
        public Book Book { get; set; }
        public int Quantity { get; set; }

        public decimal Total
        {
            get
            {
                return Book.Price * Quantity;
            }
        }
    }
}
