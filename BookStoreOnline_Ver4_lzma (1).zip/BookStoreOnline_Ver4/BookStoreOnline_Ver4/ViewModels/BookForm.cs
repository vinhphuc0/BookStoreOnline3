﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Dữ liệu thêm/sửa sách và kiểm tra giá, tồn kho, trường bắt buộc.
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class BookForm
    {
        [Required, StringLength(50)]
        public string Language { get; set; } = "Tiếng Việt";

        [Required, StringLength(50)]
        public string Binding { get; set; } = "Bìa mềm";

        [StringLength(50)]
        public string Dimensions { get; set; } = "";

        [StringLength(150)]
        public string Translator { get; set; } = "";

        [StringLength(500)]
        public string SourceUrl { get; set; } = "";
        public int Id { get; set; }

        [Required, StringLength(250)]
        public string Title { get; set; } = "";

        [Required, StringLength(20000)]
        public string Description { get; set; } = "";

        [Required, StringLength(30)]
        public string Isbn { get; set; } = "";

        [Range(1, int.MaxValue)]
        public int CategoryId { get; set; }

        [Range(1, int.MaxValue)]
        public int AuthorId { get; set; }

        [Range(1, int.MaxValue)]
        public int PublisherId { get; set; }

        [Range(1000, 100000000)]
        public decimal Price { get; set; }

        [Range(1000, 100000000)]
        public decimal ListPrice { get; set; }

        [Range(0, 100000)]
        public int Stock { get; set; }

        [Range(1, 10000)]
        public int Pages { get; set; }

        [Range(0, 2100)] // 0: nguồn chưa công bố năm, không tự đoán.
        public int Year { get; set; } = 2026;

        [DisplayFormat(ConvertEmptyStringToNull = false)]
        public string SampleText { get; set; } = "";
        public bool IsActive { get; set; } = true;
        public HttpPostedFileBase Cover { get; set; }
    }
}
