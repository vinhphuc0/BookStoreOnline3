﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using BookStoreOnline.Models;

namespace BookStoreOnline.ViewModels
{
    // Dữ liệu dùng cho form hoặc màn hình; không phải bảng database.
    public class HomeShelf
    {
        public int CategoryId { get; set; }
        public string Name { get; set; } = "";
        public List<Book> Books { get; set; } = new List<Book>();
    }
}
