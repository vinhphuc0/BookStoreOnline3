﻿using System;
using System.Collections.Generic;

namespace BookStoreOnline.Models
{
    // Đối tượng tương ứng bảng database, được EF6 ánh xạ qua EDMX.
    public partial class User
    {
        public int Id { get; set; }
        public string FullName { get; set; } = "";
        public string Email { get; set; } = "";
        public string PasswordHash { get; set; } = "";
        public string Role { get; set; } = "Customer";
        public bool IsActive { get; set; } = true;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
