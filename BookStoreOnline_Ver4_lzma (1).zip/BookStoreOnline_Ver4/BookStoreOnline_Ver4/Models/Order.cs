﻿using System;
using System.Collections.Generic;

namespace BookStoreOnline.Models
{
    // Đối tượng tương ứng bảng database, được EF6 ánh xạ qua EDMX.
    public partial class Order
    {
        public int Id { get; set; }
        public string CheckoutKey { get; set; } = "";
        public int UserId { get; set; }
        public string Recipient { get; set; } = "";
        public string Phone { get; set; } = "";
        public string Address { get; set; } = "";
        public string Note { get; set; } = "";
        public decimal ShippingFee { get; set; }
        public decimal Total { get; set; }
        public string PaymentStatus { get; set; } = "Chờ thanh toán";
        public string Status { get; set; } = "Đang xử lý";
        public string PaymentMethod { get; set; } = "COD";
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public User User { get; set; }
        public ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
    }
}
