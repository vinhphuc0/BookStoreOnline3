﻿using System;
using System.Collections.Generic;

namespace BookStoreOnline.Models
{
    // Đối tượng tương ứng bảng database, được EF6 ánh xạ qua EDMX.
    public partial class Publisher
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
    }
}
