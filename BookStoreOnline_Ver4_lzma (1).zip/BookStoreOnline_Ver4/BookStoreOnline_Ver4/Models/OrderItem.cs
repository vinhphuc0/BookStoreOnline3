﻿using System;
using System.Collections.Generic;

namespace BookStoreOnline.Models
{
    // Đối tượng tương ứng bảng database, được EF6 ánh xạ qua EDMX.
    public partial class OrderItem
    {
        public int Id { get; set; }
        public int OrderId { get; set; }
        public int BookId { get; set; }
        public string BookTitle { get; set; } = "";
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public Order Order { get; set; }
        public Book Book { get; set; }
    }
}
