@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\CapNhatDonHang.ps1" -UpgradeBooks -PrepareCatalog
pause
