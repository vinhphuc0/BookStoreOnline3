﻿using System.Web.Mvc;
using System.Web.Routing;

namespace BookStoreOnline
{
    public static class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            // HomeController ở cửa hàng khác HomeController trong Area Admin.
            Route route = routes.MapRoute("Default", "{controller}/{action}/{id}", new { controller = "Home", action = "Index", id = UrlParameter.Optional }, new[] { "BookStoreOnline.Controllers" });
            route.DataTokens["UseNamespaceFallback"] = false;
        }
    }
}
