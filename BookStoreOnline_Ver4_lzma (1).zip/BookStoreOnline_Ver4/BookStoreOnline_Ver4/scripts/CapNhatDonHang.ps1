﻿param(
    [switch]$CheckOnly,
    [switch]$UpgradeBooks,
    [switch]$PrepareCatalog,
    [string]$ConfigPath = (Join-Path (Split-Path -Parent $PSScriptRoot) 'Web.config')
)

$ErrorActionPreference = 'Stop'
$connection = $null
try {
    if (-not (Test-Path -LiteralPath $ConfigPath)) {
        throw 'Khong tim thay Web.config. Dat scripts cung thu muc source cua website.'
    }
    [xml]$config = Get-Content -LiteralPath $ConfigPath -Raw
    $entry = $config.SelectSingleNode("/configuration/connectionStrings/add[@name='BookStoreContext']")
    if ($null -eq $entry) {
        throw 'Web.config khong co connectionStrings/add ten BookStoreContext.'
    }
    $raw = $entry.GetAttribute('connectionString')
    if ([string]::IsNullOrWhiteSpace($raw)) {
        throw 'BookStoreContext trong Web.config chua co connectionString.'
    }

    if ($entry.GetAttribute('providerName') -eq 'System.Data.SqlClient') {
        $sqlConnectionString = $raw
    } else {
        # Goi truc tiep ham .NET: tranh PowerShell coi ConnectionString la khoa dictionary.
        $entity = New-Object System.Data.Common.DbConnectionStringBuilder
        $entity.set_ConnectionString($raw)
        if (-not $entity.ContainsKey('provider connection string')) {
            throw 'Chuoi EntityClient thieu provider connection string.'
        }
        $sqlConnectionString = [string]$entity.get_Item('provider connection string')
    }
    if ([string]::IsNullOrWhiteSpace($sqlConnectionString)) {
        throw 'Chuoi ket noi SQL doc duoc bi rong. Chua thuc hien cap nhat database.'
    }

    if ($CheckOnly) {
        Write-Host 'DA DOC DUOC KET NOI. Che do kiem tra, CHUA ket noi SQL hoac cap nhat database.'
        exit 0
    }

    $connection = New-Object System.Data.SqlClient.SqlConnection
    $connection.ConnectionString = $sqlConnectionString
    Write-Host ('SQL Server: ' + $connection.DataSource)
    Write-Host ('Database: ' + $connection.Database)
    $connection.Open()

    $projectRoot = Split-Path -Parent $PSScriptRoot
    # Cap nhat cau truc; chi bo sung va loc sach khi co PrepareCatalog.
    $files = @('07_mvc5_orders.sql')
    if ($UpgradeBooks) { $files = @('03_upgrade.sql', '07_mvc5_orders.sql') }
    if ($PrepareCatalog) { $files += @('02_seed.sql', '09_danh_muc_50_sach.sql') }
    $command = $connection.CreateCommand()
    $command.CommandTimeout = 120
    foreach ($name in $files) {
        $file = Join-Path $projectRoot ('Database/' + $name)
        if (-not (Test-Path -LiteralPath $file)) { throw ('Khong tim thay Database/' + $name) }
        Write-Host ('Dang chay: ' + $name)
        $command.CommandText = [System.IO.File]::ReadAllText($file, [System.Text.Encoding]::UTF8)
        [void]$command.ExecuteNonQuery()
    }
    $command.CommandText = "SELECT COL_LENGTH(N'dbo.Orders', N'PaymentStatus')"
    $length = $command.ExecuteScalar()
    if ($length -is [System.DBNull] -or $null -eq $length) { throw 'Cot PaymentStatus van chua duoc tao.' }
    Write-Host 'CAP NHAT THANH CONG. Chay website lai va mo /Admin/Orders.' -ForegroundColor Green
} catch {
    Write-Host ('CAP NHAT THAT BAI: ' + $_.Exception.GetBaseException().Message) -ForegroundColor Red
    exit 1
} finally {
    if ($null -ne $connection) { $connection.Dispose() }
}
