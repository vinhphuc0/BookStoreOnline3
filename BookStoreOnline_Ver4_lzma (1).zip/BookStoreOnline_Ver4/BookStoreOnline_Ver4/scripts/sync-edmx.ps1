﻿$ErrorActionPreference = "Stop"
$taskRoot = Split-Path $PSScriptRoot -Parent
[xml]$model = Get-Content (Join-Path $taskRoot "Data/BookStoreModel.edmx") -Raw
$ns = New-Object System.Xml.XmlNamespaceManager($model.NameTable)
$ns.AddNamespace("e", "http://schemas.microsoft.com/ado/2009/11/edmx")
$nodes = @{ csdl="/e:Edmx/e:Runtime/e:ConceptualModels/*"; ssdl="/e:Edmx/e:Runtime/e:StorageModels/*"; msl="/e:Edmx/e:Runtime/e:Mappings/*" }
foreach ($extension in $nodes.Keys) {
 $node = $model.SelectSingleNode($nodes[$extension], $ns)
 if ($null -eq $node) { throw "Missing metadata $extension" }
 [System.IO.File]::WriteAllText((Join-Path $taskRoot "Data/BookStoreModel.$extension"), $node.OuterXml, (New-Object System.Text.UTF8Encoding($false)))
}
Write-Host "Metadata synced. Rebuild the solution."
