﻿// JavaScript chỉ hỗ trợ giao diện. Dữ liệu luôn được kiểm tra lại trong Controller.
var appRoot = document.body.getAttribute('data-app-root') || '/';
function appUrl(path) {
    return appRoot + path.replace(/^\//, '');
}

// Các nút trong giỏ cần được gắn lại sau khi thay nội dung bằng AJAX.
function bindCartControls(root) {
    root.querySelectorAll('form[data-confirm]').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!window.confirm(form.getAttribute('data-confirm'))) event.preventDefault();
        });
    });
    root.querySelectorAll('[data-remove]').forEach(function (button) {
        button.addEventListener('click', function () {
            var form = button.closest('form');
            form.querySelector('input[name="quantity"]').value = '0';
            form.requestSubmit();
        });
    });
    root.querySelectorAll('[data-quantity-step]').forEach(function (button) {
        button.addEventListener('click', function () {
            var input = button.closest('.quantity-stepper').querySelector('input');
            var value = Number(input.value);
            var step = Number(button.getAttribute('data-quantity-step'));
            if (!Number.isFinite(value)) value = Number(input.min);
            input.value = Math.max(Number(input.min), Math.min(Number(input.max), value + step));
        });
    });
}
bindCartControls(document);

// 3. Chặn bấm Đặt hàng lặp trong lúc chờ phản hồi.
document.querySelectorAll('[data-submit-once]').forEach(function (button) {
    button.closest('form').addEventListener('submit', function () {
        button.disabled = true;
        button.textContent = 'Đang xử lý...';
    });
});

// 4. Lọc giá và thay đổi cách sắp xếp.
document.querySelectorAll('[data-price]').forEach(function (button) {
    button.addEventListener('click', function () {
        var form = button.closest('form');
        var prices = button.getAttribute('data-price').split(',');
        form.elements.minPrice.value = prices[0];
        form.elements.maxPrice.value = prices[1];
        form.requestSubmit();
    });
});
var sortSelect = document.querySelector('[data-catalog-sort]');
if (sortSelect) {
    sortSelect.addEventListener('change', function () {
        document.getElementById('catalog-filter').requestSubmit();
    });
}

// 6. Gợi ý tìm kiếm. Nếu mạng lỗi, người dùng vẫn gửi form tìm bình thường.
var search = document.getElementById('site-search');
var suggestions = document.getElementById('book-suggestions');
var searchTimer;
if (search && suggestions) {
    search.addEventListener('input', function () {
        clearTimeout(searchTimer);
        suggestions.replaceChildren();
        var query = search.value.trim();
        if (query.length < 2) return;
        searchTimer = setTimeout(function () {
            fetch(appUrl('Home/Suggest?q=') + encodeURIComponent(query))
                .then(function (response) {
                    if (!response.ok) throw new Error('Không tải được gợi ý');
                    return response.json();
                })
                .then(function (rows) {
                    if (search.value.trim() !== query) return;
                    suggestions.replaceChildren();
                    rows.forEach(function (row) {
                        var option = document.createElement('option');
                        option.value = row.title;
                        suggestions.appendChild(option);
                    });
                })
                .catch(function () { /* Không chặn thao tác tìm kiếm chính. */ });
        }, 300);
    });
}

// 7. Hiện hoặc ẩn mật khẩu.
document.querySelectorAll('[data-password-toggle]').forEach(function (button) {
    button.addEventListener('click', function () {
        var input = document.getElementById(button.getAttribute('data-password-toggle'));
        var show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        button.textContent = show ? 'Ẩn' : 'Hiện';
        button.setAttribute('aria-pressed', String(show));
    });
});

// 8. Kệ sách theo thể loại; nút mũi tên/Home/End hỗ trợ dùng bàn phím.
document.querySelectorAll('[data-shelf-tabs]').forEach(function (nav) {
    var tabs = Array.from(nav.querySelectorAll('[data-shelf-tab]'));
    var panels = tabs.map(function (tab) {
        return document.getElementById(tab.getAttribute('data-shelf-tab'));
    });
    if (tabs.length === 0 || panels.some(function (panel) { return !panel; })) return;
    nav.setAttribute('role', 'tablist');
    function selectTab(index, focus) {
        tabs.forEach(function (tab, i) {
            tab.setAttribute('role', 'tab');
            tab.setAttribute('aria-selected', String(i === index));
            tab.setAttribute('tabindex', i === index ? '0' : '-1');
            tab.setAttribute('aria-controls', panels[i].id);
            panels[i].setAttribute('role', 'tabpanel');
            panels[i].setAttribute('aria-labelledby', tab.id);
            panels[i].hidden = i !== index;
        });
        if (focus) tabs[index].focus();
    }
    var initial = 0;
    panels.forEach(function (panel, index) { if ('#' + panel.id === location.hash) initial = index; });
    selectTab(initial, false);
    tabs.forEach(function (tab, index) {
        tab.addEventListener('click', function (event) { event.preventDefault(); selectTab(index, false); });
        tab.addEventListener('keydown', function (event) {
            var next = index;
            if (event.key === 'ArrowRight') next = (index + 1) % tabs.length;
            else if (event.key === 'ArrowLeft') next = (index - 1 + tabs.length) % tabs.length;
            else if (event.key === 'Home') next = 0;
            else if (event.key === 'End') next = tabs.length - 1;
            else return;
            event.preventDefault();
            selectTab(next, true);
        });
    });
});

// 9. Phóng to bìa và thu gọn phần giới thiệu dài.
var cover = document.querySelector('[data-cover-dialog]');
var openCover = document.querySelector('[data-cover-open]');
var closeCover = document.querySelector('[data-cover-close]');
if (cover && openCover && closeCover && typeof cover.showModal === 'function') {
    openCover.addEventListener('click', function () { cover.showModal(); });
    closeCover.addEventListener('click', function () { cover.close(); });
    cover.addEventListener('click', function (event) { if (event.target === cover) cover.close(); });
}
var description = document.querySelector('[data-description]');
var descriptionToggle = document.querySelector('[data-description-toggle]');
if (description && descriptionToggle) {
    if (description.scrollHeight > 300) {
        description.classList.add('is-collapsed');
        descriptionToggle.hidden = false;
    }
    descriptionToggle.addEventListener('click', function () {
        var expanded = descriptionToggle.getAttribute('aria-expanded') !== 'true';
        description.classList.toggle('is-collapsed', !expanded);
        descriptionToggle.setAttribute('aria-expanded', String(expanded));
        descriptionToggle.textContent = expanded ? 'Thu gọn giới thiệu ↑' : 'Xem thêm giới thiệu ↓';
    });
}

// 10. Sao chép liên kết, về đầu trang và bố cục điện thoại.
var copyButton = document.querySelector('[data-copy-link]');
if (copyButton) {
    copyButton.addEventListener('click', function () {
        var status = document.querySelector('[data-copy-status]');
        if (!navigator.clipboard) { status.textContent = 'Sao chép địa chỉ trên thanh trình duyệt.'; return; }
        navigator.clipboard.writeText(location.href)
            .then(function () { status.textContent = 'Đã sao chép'; })
            .catch(function () { status.textContent = 'Sao chép địa chỉ trên thanh trình duyệt.'; });
    });
}
var topButton = document.querySelector('.back-to-top');
if (topButton) {
    window.addEventListener('scroll', function () { topButton.hidden = window.scrollY < 600; });
    topButton.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
}
if (document.querySelector('.mobile-purchase-bar')) document.body.classList.add('has-mobile-purchase');
if (window.matchMedia('(max-width: 640px)').matches) {
    document.querySelectorAll('.filter-details').forEach(function (details) { details.open = false; });
}

// 11. Ảnh hỏng dùng ảnh mặc định, không lặp tải lại vô hạn.
function fallbackImage(image) {
    if (!(image instanceof HTMLImageElement) || image.getAttribute('data-fallback') === 'true') return;
    image.setAttribute('data-fallback', 'true');
    image.src = appUrl('images/default.svg');
}
document.addEventListener('error', function (event) { fallbackImage(event.target); }, true);
document.querySelectorAll('img').forEach(function (image) {
    if (image.complete && image.naturalWidth === 0) fallbackImage(image);
});

// 12. Kiểm tra nhập liệu bằng JavaScript thuần; server vẫn kiểm tra lại.
document.querySelectorAll('[data-digits-only]').forEach(function (input) {
    input.addEventListener('input', function () {
        input.value = input.value.replace(/[^0-9]/g, '').slice(0, 10);
    });
    input.addEventListener('paste', function (event) {
        event.preventDefault();
        var digits = event.clipboardData.getData('text').replace(/[^0-9]/g, '');
        var start = input.selectionStart;
        var end = input.selectionEnd;
        input.value = (input.value.slice(0, start) + digits + input.value.slice(end)).slice(0, 10);
    });
});

document.querySelectorAll('[data-no-leading-space]').forEach(function (input) {
    function checkLeadingSpace() {
        var hasSpace = /^\s/.test(input.value);
        input.setCustomValidity(hasSpace ? 'Không được có khoảng trắng ở đầu.' : '');
    }
    input.addEventListener('input', checkLeadingSpace);
    checkLeadingSpace();
});

// maxlength chặn nhập quá giới hạn; bộ đếm tính cả dấu cách và xuống dòng.
document.querySelectorAll('[data-character-limit]').forEach(function (input) {
    var limit = Number(input.getAttribute('data-character-limit'));
    var counter = document.createElement('small');
    counter.className = 'character-counter input-help';
    input.insertAdjacentElement('afterend', counter);
    function countCharacters() {
        var count = input.value.length;
        counter.textContent = count + ' / ' + limit + ' ký tự';
        input.setCustomValidity(count > limit ? 'Chỉ được nhập tối đa ' + limit + ' ký tự.' : '');
        counter.classList.toggle('text-danger', count > limit);
    }
    input.addEventListener('input', countCharacters);
    countCharacters();
});

// 13. Thêm giỏ / yêu thích tại chỗ, không chuyển trang hoặc cuộn lại.
var noticeTimer;
function showQuickNotice(message, isError) {
    var notice = document.getElementById('quick-notice');
    if (!notice) {
        notice = document.createElement('div');
        notice.id = 'quick-notice';
        notice.className = 'quick-notice';
        notice.setAttribute('role', 'status');
        notice.setAttribute('aria-live', 'polite');
        document.body.appendChild(notice);
    }
    notice.textContent = message;
    notice.classList.toggle('is-error', isError);
    notice.hidden = false;
    clearTimeout(noticeTimer);
    noticeTimer = setTimeout(function () { notice.hidden = true; }, 4000);
}

function updateQuickCounts(selector, count) {
    document.querySelectorAll(selector).forEach(function (element) {
        element.textContent = count;
    });
}

// Chỉ cập nhật vùng Cart. Tiền, phí ship và nút Checkout do Razor tính lại.
var cartContentBusy = false;
var cartAddBusy = false;
function refreshCartContent(message) {
    var container = document.getElementById('cart-content');
    if (!container || cartContentBusy) return;
    cartContentBusy = true;
    container.setAttribute('aria-busy', 'true');
    container.setAttribute('inert', '');
    var scrollX = window.scrollX;
    var scrollY = window.scrollY;
    var request = new XMLHttpRequest();
    request.open('GET', container.getAttribute('data-refresh-url'));
    request.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    request.timeout = 15000;
    function finishRefresh() {
        cartContentBusy = false;
        container.removeAttribute('aria-busy');
        container.removeAttribute('inert');
    }
    function showRefreshError() {
        finishRefresh();
        // Không để tổng tiền cũ hiển thị như thể vẫn đúng khi tải lại giỏ thất bại.
        container.innerHTML = '';
        var error = document.createElement('p');
        error.className = 'alert alert-warning';
        error.textContent = 'Giỏ đã thay đổi nhưng chưa tải được nội dung mới. Bấm cập nhật để xem tổng tiền chính xác.';
        var retry = document.createElement('button');
        retry.type = 'button';
        retry.className = 'btn btn-forest';
        retry.textContent = 'Cập nhật giỏ hàng';
        retry.addEventListener('click', function () { refreshCartContent('Đã cập nhật giỏ hàng.'); });
        container.appendChild(error);
        container.appendChild(retry);
        showQuickNotice('Chưa tải được giỏ hàng. Hãy bấm cập nhật.', true);
    }
    request.onload = function () {
        if (request.status !== 200 || request.responseText.indexOf('data-cart-total-count=') < 0) {
            showRefreshError();
            return;
        }
        container.innerHTML = request.responseText;
        bindCartControls(container);
        bindQuickActions(container);
        // Đồng bộ badge kể cả khi một tab khác đã sửa giỏ trước lần tải này.
        var count = container.querySelector('[data-cart-total-count]');
        if (count) updateQuickCounts('[data-cart-count]', Number(count.getAttribute('data-cart-total-count')));
        finishRefresh();
        window.scrollTo(scrollX, scrollY);
        showQuickNotice(message, false);
    };
    request.onerror = request.ontimeout = showRefreshError;
    request.send();
}

function bindQuickActions(root) {
    root.querySelectorAll('form[data-quick-action]').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            // Mua ngay vẫn mở Checkout; chỉ nút Thêm vào giỏ giữ nguyên trang.
            var submitter = event.submitter;
            if (submitter && submitter.name === 'proceed' && submitter.value === 'checkout') return;
            event.preventDefault();
            if ((cartContentBusy || cartAddBusy) && form.getAttribute('data-quick-action') === 'cart') {
                showQuickNotice('Đang cập nhật giỏ, bạn chờ một chút.', false);
                return;
            }
            if (form.getAttribute('data-busy') === 'true') return;
            form.setAttribute('data-busy', 'true');
            var cartContainer = document.getElementById('cart-content');
            var addingOnCart = cartContainer && form.getAttribute('data-quick-action') === 'cart';
            if (addingOnCart) {
                cartAddBusy = true;
                cartContainer.setAttribute('inert', '');
            }
            var buttons = Array.from(form.querySelectorAll('button[type="submit"], button:not([type]), input[type="submit"]'));
            buttons = buttons.filter(function (button) { return !button.disabled; });
            buttons.forEach(function (button) { button.disabled = true; });
            var request = new XMLHttpRequest();
            request.open('POST', form.action);
            request.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
            request.timeout = 15000;
            function finish() {
                if (addingOnCart) {
                    cartAddBusy = false;
                    cartContainer.removeAttribute('inert');
                }
                form.removeAttribute('data-busy');
                buttons.forEach(function (button) { button.disabled = false; });
            }
            request.onload = function () {
                finish();
                var result;
                try { result = JSON.parse(request.responseText); }
                catch (error) {
                    showQuickNotice('Chưa thể thực hiện. Hãy thử lại hoặc mở lại trang khi phiên hết hạn.', true);
                    return;
                }
                if (request.status !== 200 || !result.success) {
                    showQuickNotice(result.message || 'Chưa thể thực hiện thao tác.', true);
                    return;
                }
                if (typeof result.cartCount === 'number') {
                    updateQuickCounts('[data-cart-count]', result.cartCount);
                    if (document.getElementById('cart-content')) {
                        refreshCartContent(result.message);
                        return;
                    }
                }
                if (typeof result.favoriteCount === 'number') {
                    updateQuickCounts('[data-favorite-count]', result.favoriteCount);
                    document.querySelectorAll('form[data-quick-action="favorite"]').forEach(function (favoriteForm) {
                        if (favoriteForm.getAttribute('data-book-id') !== String(result.id)) return;
                        var button = favoriteForm.querySelector('button[type="submit"]');
                        button.setAttribute('aria-pressed', String(result.isFavorite));
                        button.setAttribute('aria-label', result.isFavorite ? 'Bỏ yêu thích' : 'Thêm yêu thích');
                        button.classList.toggle('is-saved', result.isFavorite);
                        if (button.classList.contains('favorite-button')) {
                            button.textContent = result.isFavorite ? '♥' : '♡';
                        } else {
                            button.textContent = result.isFavorite ? '♥ Đã lưu yêu thích' : '♡ Lưu vào yêu thích';
                        }
                    });
                }
                showQuickNotice(result.message, false);
            };
            request.onerror = request.ontimeout = function () {
                finish();
                showQuickNotice('Không nhận được phản hồi. Kiểm tra kết nối rồi thử lại.', true);
            };
            // FormData gửi cả AntiForgeryToken; không bỏ kiểm tra token phía server.
            request.send(new FormData(form));
        });
    });
}
bindQuickActions(document);

// 14. Chặn ảnh quá lớn ngay trước khi gửi multipart lên IIS.
var coverInput = document.querySelector('[data-cover-upload]');
if (coverInput) {
    var coverForm = coverInput.closest('form');
    var coverError = coverForm.querySelector('[data-cover-error]');
    function checkCover() {
        var file = coverInput.files[0];
        var message = '';
        if (file && !/\.(jpe?g|png)$/i.test(file.name)) {
            message = 'Chỉ chọn ảnh JPG hoặc PNG; ảnh HEIC/WebP cần chuyển định dạng trước.';
        } else if (file && (file.size === 0 || file.size > 5 * 1024 * 1024)) {
            message = 'Ảnh bìa không được rỗng hoặc lớn hơn 5 MB. Hãy chọn ảnh nhỏ hơn.';
        }
        coverInput.setCustomValidity(message);
        coverError.textContent = message;
        return message === '';
    }
    coverInput.addEventListener('change', checkCover);
    coverForm.addEventListener('submit', function (event) {
        if (!checkCover()) {
            event.preventDefault();
            coverInput.reportValidity();
        }
    });
}

// 15. Đóng menu danh mục sách khi click ra ngoài hoặc chọn mục.
document.addEventListener('click', function (event) {
    var categoryMenu = document.querySelector('.nav-category-menu[open]');
    if (!categoryMenu) return;
    if (!categoryMenu.contains(event.target) || event.target.closest('.nav-category-dropdown a')) {
        categoryMenu.removeAttribute('open');
    }
});
