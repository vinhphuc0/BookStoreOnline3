﻿-- Chi dung de tao database MOI. Database cu: chay 03 roi 07.
USE master;
GO
IF DB_ID(N'BookStoreOnline') IS NULL
    CREATE DATABASE BookStoreOnline;
GO
USE BookStoreOnline;
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;

IF EXISTS (SELECT 1 FROM sys.tables WHERE schema_id = SCHEMA_ID(N'dbo'))
    THROW 51000, N'Database da co bang. Khong chay lai 01; hay dung 03 va 07 de nang cap.', 1;

BEGIN TRY
    BEGIN TRANSACTION;

    CREATE TABLE dbo.Categories (
        Id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        Name nvarchar(100) NOT NULL UNIQUE
    );
    CREATE TABLE dbo.Authors (
        Id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        Name nvarchar(150) NOT NULL UNIQUE
    );
    CREATE TABLE dbo.Publishers (
        Id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        Name nvarchar(150) NOT NULL UNIQUE
    );
    CREATE TABLE dbo.Users (
        Id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        FullName nvarchar(100) NOT NULL,
        Email nvarchar(254) NOT NULL UNIQUE,
        PasswordHash nvarchar(600) NOT NULL,
        Role nvarchar(20) NOT NULL CONSTRAINT DF_Users_Role DEFAULT N'Customer',
        IsActive bit NOT NULL CONSTRAINT DF_Users_IsActive DEFAULT 1,
        CreatedAt datetime2(7) NOT NULL CONSTRAINT DF_Users_CreatedAt DEFAULT SYSUTCDATETIME(),
        CONSTRAINT CK_Users_Role CHECK (Role IN (N'Customer', N'Admin'))
    );
    CREATE TABLE dbo.Books (
        Id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        Title nvarchar(250) NOT NULL,
        Description nvarchar(max) NOT NULL,
        Isbn nvarchar(30) NOT NULL,
        CategoryId int NOT NULL CONSTRAINT FK_Book_Category REFERENCES dbo.Categories(Id),
        AuthorId int NOT NULL CONSTRAINT FK_Book_Author REFERENCES dbo.Authors(Id),
        PublisherId int NOT NULL CONSTRAINT FK_Book_Publisher REFERENCES dbo.Publishers(Id),
        Price decimal(18,0) NOT NULL,
        ListPrice decimal(18,0) NOT NULL,
        Stock int NOT NULL,
        Pages int NOT NULL,
        Year int NOT NULL,
        ImagePath nvarchar(300) NOT NULL,
        SampleText nvarchar(max) NOT NULL,
        Language nvarchar(50) NOT NULL CONSTRAINT DF_Books_Language DEFAULT N'Tiếng Việt',
        Binding nvarchar(50) NOT NULL CONSTRAINT DF_Books_Binding DEFAULT N'Bìa mềm',
        Dimensions nvarchar(50) NOT NULL CONSTRAINT DF_Books_Dimensions DEFAULT N'',
        Translator nvarchar(150) NOT NULL CONSTRAINT DF_Books_Translator DEFAULT N'',
        SourceUrl nvarchar(500) NOT NULL CONSTRAINT DF_Books_SourceUrl DEFAULT N'',
        IsActive bit NOT NULL CONSTRAINT DF_Books_IsActive DEFAULT 1,
        CreatedAt datetime2(7) NOT NULL CONSTRAINT DF_Books_CreatedAt DEFAULT SYSUTCDATETIME(),
        CONSTRAINT CK_Books_Prices CHECK (Price > 0 AND ListPrice >= Price),
        CONSTRAINT CK_Books_Stock CHECK (Stock >= 0)
    );
    CREATE TABLE dbo.Orders (
        Id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        CheckoutKey nvarchar(32) NOT NULL CONSTRAINT UQ_Orders_CheckoutKey UNIQUE,
        UserId int NOT NULL CONSTRAINT FK_Order_User REFERENCES dbo.Users(Id),
        Recipient nvarchar(max) NOT NULL,
        Phone nvarchar(20) NOT NULL,
        Address nvarchar(max) NOT NULL,
        Note nvarchar(max) NOT NULL,
        ShippingFee decimal(18,0) NOT NULL,
        Total decimal(18,0) NOT NULL,
        Status nvarchar(30) NOT NULL CONSTRAINT DF_Orders_Status DEFAULT N'Đang xử lý',
        PaymentStatus nvarchar(30) NOT NULL CONSTRAINT DF_Orders_PaymentStatus DEFAULT N'Chờ thanh toán',
        PaymentMethod nvarchar(20) NOT NULL CONSTRAINT DF_Orders_PaymentMethod DEFAULT N'COD',
        CreatedAt datetime2(7) NOT NULL CONSTRAINT DF_Orders_CreatedAt DEFAULT SYSUTCDATETIME(),
        CONSTRAINT CK_Orders_Status_MVC5 CHECK (Status IN (
            N'Chờ thanh toán', N'Đang xử lý', N'Đang vận chuyển', N'Đã giao', N'Đã hủy')),
        CONSTRAINT CK_Orders_PaymentStatus_MVC5 CHECK (PaymentStatus IN (N'Chờ thanh toán', N'Đã thanh toán'))
    );
    CREATE TABLE dbo.OrderItems (
        Id int IDENTITY(1,1) NOT NULL PRIMARY KEY,
        OrderId int NOT NULL CONSTRAINT FK_OrderItem_Order REFERENCES dbo.Orders(Id) ON DELETE CASCADE,
        BookId int NOT NULL CONSTRAINT FK_OrderItem_Book REFERENCES dbo.Books(Id),
        BookTitle nvarchar(250) NOT NULL,
        Quantity int NOT NULL CONSTRAINT CK_OrderItems_Quantity CHECK (Quantity > 0),
        UnitPrice decimal(18,0) NOT NULL CONSTRAINT CK_OrderItems_Price CHECK (UnitPrice > 0)
    );

    CREATE INDEX IX_Books_CategoryId ON dbo.Books(CategoryId);
    CREATE INDEX IX_Books_AuthorId ON dbo.Books(AuthorId);
    CREATE INDEX IX_Books_PublisherId ON dbo.Books(PublisherId);
    CREATE INDEX IX_Books_Isbn ON dbo.Books(Isbn);
    CREATE INDEX IX_Orders_User_Status_Created ON dbo.Orders(UserId, Status, CreatedAt DESC);
    CREATE INDEX IX_OrderItems_OrderId ON dbo.OrderItems(OrderId);
    CREATE INDEX IX_OrderItems_BookId ON dbo.OrderItems(BookId);

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
PRINT N'Da tao cau truc MVC5 day du. Tiep theo chay 02_seed.sql.';
