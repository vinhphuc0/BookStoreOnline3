﻿-- Chon dung database trong Web.config truoc khi Execute TOAN BO file.
-- Hoac chay CHAY_SQL_07.cmd de lay dung ket noi tu Web.config.
-- Sao luu database truoc. Khong chay 01 tren database dang su dung.
SET NOCOUNT ON;
SET XACT_ABORT ON;

IF DB_NAME() IN (N'master', N'model', N'msdb', N'tempdb')
    THROW 51000, N'Hay chon database cua website, khong chay tren database he thong.', 1;
IF OBJECT_ID(N'dbo.Orders', N'U') IS NULL
    THROW 51001, N'Database dang chon khong co dbo.Orders. Kiem tra ket noi trong Web.config.', 1;

SELECT CONVERT(nvarchar(128), SERVERPROPERTY('ServerName')) AS SqlServer,
       DB_NAME() AS DatabaseDangCapNhat;

BEGIN TRY
    BEGIN TRANSACTION;

    IF EXISTS (
        SELECT 1 FROM dbo.Orders
        WHERE Status IS NULL OR Status NOT IN (
            N'Chờ duyệt', N'Đang giao', N'Chờ thanh toán', N'Đang xử lý',
            N'Đang vận chuyển', N'Đã giao', N'Đã hủy')
    )
        THROW 51007, N'Co trang thai don hang ngoai gia tri ho tro. Chua thay doi du lieu.', 1;

    -- Bo quy tac trang thai cu TRUOC moi UPDATE tren Orders.
    -- Nhan dien bang cot/phu thuoc, khong dua vao ten tu sinh cua constraint.
    DECLARE @ordersId int = OBJECT_ID(N'dbo.Orders');
    DECLARE @statusColumnId int = COLUMNPROPERTY(@ordersId, N'Status', 'ColumnId');
    DECLARE @paymentColumnId int = COLUMNPROPERTY(@ordersId, N'PaymentStatus', 'ColumnId');
    DECLARE @dropChecks nvarchar(max) = N'';
    SELECT @dropChecks = @dropChecks
        + N'ALTER TABLE dbo.Orders DROP CONSTRAINT ' + QUOTENAME(cc.name) + N';'
    FROM sys.check_constraints AS cc
    WHERE cc.parent_object_id = @ordersId
      AND (
          cc.parent_column_id IN (@statusColumnId, @paymentColumnId)
          OR EXISTS (
              SELECT 1
              FROM sys.sql_expression_dependencies AS dep
              WHERE dep.referencing_id = cc.object_id
                AND dep.referenced_id = @ordersId
                AND dep.referenced_minor_id IN (@statusColumnId, @paymentColumnId)
          )
          OR cc.name IN (N'CK_Orders_Status_MVC5', N'CK_Orders_PaymentStatus_MVC5')
      );
    IF @dropChecks <> N''
        EXEC sys.sp_executesql @dropChecks;

    IF COL_LENGTH(N'dbo.Orders', N'PaymentStatus') IS NULL
    BEGIN
        EXEC sys.sp_executesql N'
            ALTER TABLE dbo.Orders ADD PaymentStatus nvarchar(30) NOT NULL
                CONSTRAINT DF_Orders_PaymentStatus DEFAULT N''Chờ thanh toán'';';
        EXEC sys.sp_executesql N'
            UPDATE dbo.Orders SET PaymentStatus = N''Đã thanh toán''
            WHERE Status = N''Đã giao'' AND PaymentMethod = N''COD'';';
    END;

    -- Cot moi chi duoc tham chieu trong batch dong, tranh loi Invalid column name.
    EXEC sys.sp_executesql N'
        UPDATE dbo.Orders SET PaymentStatus = N''Chờ thanh toán''
        WHERE PaymentStatus IS NULL OR LTRIM(RTRIM(PaymentStatus)) = N'''';
        IF EXISTS (SELECT 1 FROM dbo.Orders
                   WHERE PaymentStatus NOT IN (N''Chờ thanh toán'', N''Đã thanh toán''))
            THROW 51008, N''PaymentStatus co gia tri chua duoc ho tro. Dung de kiem tra.'', 1;';

    DECLARE @dropDefault nvarchar(max);
    DECLARE @paymentDefault sysname;
    SELECT @paymentDefault = dc.name
    FROM sys.default_constraints AS dc
    JOIN sys.columns AS c ON c.object_id = dc.parent_object_id AND c.column_id = dc.parent_column_id
    WHERE c.object_id = @ordersId AND c.name = N'PaymentStatus';
    IF @paymentDefault IS NOT NULL
    BEGIN
        SET @dropDefault = N'ALTER TABLE dbo.Orders DROP CONSTRAINT ' + QUOTENAME(@paymentDefault) + N';';
        EXEC sys.sp_executesql @dropDefault;
    END;
    EXEC sys.sp_executesql N'ALTER TABLE dbo.Orders ALTER COLUMN PaymentStatus nvarchar(30) NOT NULL;';

    UPDATE dbo.Orders SET Status = N'Đang xử lý' WHERE Status = N'Chờ duyệt';
    UPDATE dbo.Orders SET Status = N'Đang vận chuyển' WHERE Status = N'Đang giao';

    DECLARE @defaultName sysname;
    SELECT @defaultName = d.name
    FROM sys.default_constraints d
    JOIN sys.columns c ON c.object_id = d.parent_object_id AND c.column_id = d.parent_column_id
    WHERE c.object_id = OBJECT_ID(N'dbo.Orders') AND c.name = N'Status';
    IF @defaultName IS NOT NULL
    BEGIN
        SET @dropDefault = N'ALTER TABLE dbo.Orders DROP CONSTRAINT '
            + QUOTENAME(@defaultName) + N';';
        EXEC sys.sp_executesql @dropDefault;
    END;

    ALTER TABLE dbo.Orders ADD CONSTRAINT DF_Orders_Status DEFAULT N'Đang xử lý' FOR Status;
    ALTER TABLE dbo.Orders WITH CHECK ADD CONSTRAINT CK_Orders_Status_MVC5
        CHECK (Status IN (N'Chờ thanh toán', N'Đang xử lý', N'Đang vận chuyển', N'Đã giao', N'Đã hủy'));

    EXEC sys.sp_executesql N'
        ALTER TABLE dbo.Orders ADD CONSTRAINT DF_Orders_PaymentStatus
            DEFAULT N''Chờ thanh toán'' FOR PaymentStatus;
        ALTER TABLE dbo.Orders WITH CHECK ADD CONSTRAINT CK_Orders_PaymentStatus_MVC5
            CHECK (PaymentStatus IN (N''Chờ thanh toán'', N''Đã thanh toán''));';

    IF NOT EXISTS (SELECT 1 FROM sys.indexes
                   WHERE object_id = OBJECT_ID(N'dbo.Orders') AND name = N'IX_Orders_User_Status_Created')
        CREATE INDEX IX_Orders_User_Status_Created ON dbo.Orders(UserId, Status, CreatedAt DESC);

    -- Giới hạn ký tự được kiểm tra trong CheckoutForm: người nhận 100, địa chỉ/ghi chú 500.
    -- Giữ nvarchar(max) để không cắt nội dung của các đơn cũ.
    ALTER TABLE dbo.Orders ALTER COLUMN Recipient nvarchar(max) NOT NULL;
    ALTER TABLE dbo.Orders ALTER COLUMN Address nvarchar(max) NOT NULL;
    ALTER TABLE dbo.Orders ALTER COLUMN Note nvarchar(max) NOT NULL;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0
        ROLLBACK TRANSACTION;
    THROW;
END CATCH;

SELECT DB_NAME() AS DatabaseDaCapNhat,
       COL_LENGTH(N'dbo.Orders', N'PaymentStatus') AS PaymentStatus_Bytes;
PRINT N'CAP NHAT THANH CONG. Quay lai website va tai lai trang.';
