﻿-- 50 sach that: du lieu, ISBN, gia va bia doi chieu NXB Kim Dong ngay 08/11/2026.
-- Chon dung database. Database cu sao luu truoc, chay 03 va 07 truoc file nay.
-- Dong bo thong tin sach; GIU ton kho sach da co. Sach moi khoi tao theo du lieu nguon.
SET NOCOUNT ON;
SET XACT_ABORT ON;
IF DB_NAME() IN (N'master', N'model', N'msdb', N'tempdb')
    THROW 51000, N'Hay chon database cua website.', 1;
IF OBJECT_ID(N'dbo.Books', N'U') IS NULL OR COL_LENGTH(N'dbo.Books', N'SourceUrl') IS NULL
    THROW 51001, N'Chua du cau truc sach. Database moi chay 01; database cu chay 03 truoc.', 1;

DECLARE @Catalog TABLE (
    Isbn nvarchar(30) PRIMARY KEY,
    Title nvarchar(250), Description nvarchar(max),
    CategoryName nvarchar(100), AuthorName nvarchar(150), PublisherName nvarchar(150),
    Price decimal(18,0), ListPrice decimal(18,0), InitialStock int, Pages int, Year int,
    ImagePath nvarchar(300), SampleText nvarchar(max), Language nvarchar(50),
    Binding nvarchar(50), Dimensions nvarchar(50), Translator nvarchar(150), SourceUrl nvarchar(500)
);
INSERT INTO @Catalog VALUES
    (
        N'9786042037310',
        N'Chuột Típ đến thăm ông bà',
        N'Những sinh hoạt của Chuột Típ gợi cho trẻ cách ứng xử với gia đình và các thói quen hằng ngày.

Tác giả: Marco Campanella; Anna Casalis. Nhà xuất bản Kim Đồng. 28 trang, bìa mềm.',
        N'Truyện tranh',
        N'Marco Campanella; Anna Casalis',
        N'NXB Kim Đồng',
        22500,
        25000,
        10,
        28,
        0,
        N'/images/real/9786042037310.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'18.5x20.5 cm',
        N'',
        N'https://nxbkimdong.com.vn/chuot-tip-den-tham-ong-ba-26'
    ),
    (
        N'9786042374330',
        N'Thưởng thức triết học - Tin và biết',
        N'Cuốn sách thuộc bộ Thưởng thức triết học, gợi mở suy nghĩ về niềm tin và tri thức.

Tác giả: Brigitte Labbé; Jacques Azam; Michel Puech. Nhà xuất bản Kim Đồng. 40 trang, bìa mềm.',
        N'Kiến thức - khoa học',
        N'Brigitte Labbé; Jacques Azam; Michel Puech',
        N'NXB Kim Đồng',
        22500,
        25000,
        7,
        40,
        0,
        N'/images/real/9786042374330.jpg',
        N'PDF:https://file.hstatic.net/200000343865/file/thuong_thuc_triet_hoc_-_tin_va_biet_aed07e42bd264affae63ca0d2d4ec013.pdf',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'13x19 cm',
        N'',
        N'https://nxbkimdong.com.vn/thuong-thuc-triet-hoc-tin-va-biet-26'
    ),
    (
        N'9786042263993',
        N'Một đêm giông bão - Tập 2',
        N'Tình bạn giữa dê Mei và sói Gabu đứng trước sự ngờ vực từ hai bầy đàn.

Tác giả: Yuichi Kimura; Thùy Cốm. Nhà xuất bản Kim Đồng. 92 trang, bìa mềm.',
        N'Văn học nước ngoài',
        N'Yuichi Kimura; Thùy Cốm',
        N'NXB Kim Đồng',
        27000,
        30000,
        10,
        92,
        0,
        N'/images/real/9786042263993.jpg',
        N'PDF:https://file.hstatic.net/200000343865/file/preview_mot_dem_giong_bao_tap_2.pdf',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'13x19 cm',
        N'',
        N'https://nxbkimdong.com.vn/mot-dem-giong-bao-tap-2-26'
    ),
    (
        N'9786042378864',
        N'Mùa tiểu học cuối cùng',
        N'Kí ức về những người bạn và trò nghịch ngợm trong một lớp học ở trường tiểu học Bình Tây.

Tác giả: Lê Văn Nghĩa. Nhà xuất bản Kim Đồng. 224 trang, bìa mềm.',
        N'Văn học Việt Nam',
        N'Lê Văn Nghĩa',
        N'NXB Kim Đồng',
        54000,
        60000,
        9,
        224,
        0,
        N'/images/real/9786042378864.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'13.5x20.5 cm',
        N'',
        N'https://nxbkimdong.com.vn/mua-tieu-hoc-cuoi-cung-26'
    ),
    (
        N'9786042425650',
        N'Ngọn đồi hoa hồng anh - Tập 1',
        N'Umi và Shun cùng bảo vệ ngôi nhà câu lạc bộ, rồi đối diện một bí mật từ tấm ảnh cũ.

Tác giả: Hayao Miyazaki; Keiko Niwa; Goro Miyazaki; . Nhà xuất bản Kim Đồng. 144 trang, bìa mềm.',
        N'Manga - comic',
        N'Hayao Miyazaki; Keiko Niwa; Goro Miyazaki; ',
        N'NXB Kim Đồng',
        67500,
        75000,
        232,
        144,
        0,
        N'/images/real/9786042425650.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'13x18 cm',
        N'',
        N'https://nxbkimdong.com.vn/ngon-doi-hoa-hong-anh-tap-1'
    ),
    (
        N'9786042034838',
        N'Tranh truyện lịch sử Việt Nam - Đinh Bộ Lĩnh',
        N'Đinh Bộ Lĩnh được giới thiệu qua hình thức tranh truyện lịch sử Việt Nam.

Tác giả: Tạ Huy Long; Nam Việt. Nhà xuất bản Kim Đồng. 32 trang, bìa mềm.',
        N'Lịch sử - truyền thống',
        N'Tạ Huy Long; Nam Việt',
        N'NXB Kim Đồng',
        18000,
        20000,
        20,
        32,
        0,
        N'/images/real/9786042034838.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14,5x20,5 cm',
        N'',
        N'https://nxbkimdong.com.vn/tranh-truyen-lich-su-viet-nam-dinh-bo-linh-26'
    ),
    (
        N'9786042418492',
        N'Chuyện bên dòng Hô Lan',
        N'Tiểu thuyết tự truyện của Tiêu Hồng gợi lại tuổi thơ và đời sống bên dòng Hô Lan.

Tác giả: Tiêu Hồng. Nhà xuất bản Kim Đồng. 248 trang, bìa mềm.',
        N'Wings Books',
        N'Tiêu Hồng',
        N'NXB Kim Đồng',
        81000,
        90000,
        44,
        248,
        0,
        N'/images/real/9786042418492.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14x22,5 cm',
        N'',
        N'https://nxbkimdong.com.vn/chuyen-ben-dong-ho-lan'
    ),
    (
        N'9786042346993',
        N'Doraemon hoạt hình màu - Tập 1',
        N'Tập truyện màu về Doraemon trong dòng sách chuyển thể từ hoạt hình.

Tác giả: Fujiko F Fujio. Nhà xuất bản Kim Đồng. 144 trang, bìa mềm.',
        N'Manga - comic',
        N'Fujiko F Fujio',
        N'NXB Kim Đồng',
        31500,
        35000,
        22,
        144,
        0,
        N'/images/real/9786042346993.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'11.3x17.6 cm',
        N'',
        N'https://nxbkimdong.com.vn/doraemon-hoat-hinh-mau-tap-1-25'
    ),
    (
        N'9786042422345',
        N'Văn kiện Đại hội đại biểu toàn quốc lần thứ XIII (2026 - 2031)',
        N'Tập hợp văn kiện của Đại hội Đoàn TNCS Hồ Chí Minh lần thứ XIII, nhiệm kì 2026–2031.

Tác giả: Đoàn Thanh niên Cộng Sản Hồ Chí Minh. Nhà xuất bản Kim Đồng. 256 trang, bìa mềm.',
        N'Sách công cụ Đoàn - Đội',
        N'Đoàn Thanh niên Cộng Sản Hồ Chí Minh',
        N'NXB Kim Đồng',
        72000,
        80000,
        7,
        256,
        0,
        N'/images/real/9786042422345.jpg',
        N'PDF:https://bizweb.dktcdn.net/100/576/749/files/van_kien_dai_hoi_dai_bieu_toan_quoc_lan_thu_xiii_2026-2031_preview.pdf?v=1787818292790',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14,5x20,5 cm',
        N'',
        N'https://nxbkimdong.com.vn/van-kien-dai-hoi-dai-bieu-toan-quoc-lan-thu-xiii-2026-2031'
    ),
    (
        N'9786042394314',
        N'Hạt mầm nhân cách - Nuôi dưỡng lòng nhân hậu - Trái tim người mẹ',
        N'Câu chuyện về Margaret Haughery đưa bạn đọc nhỏ tuổi đến với chủ đề lòng nhân hậu.

Tác giả: Thanh Tâm; Lạc An. Nhà xuất bản Kim Đồng. 20 trang, bìa mềm.',
        N'Truyện tranh',
        N'Thanh Tâm; Lạc An',
        N'NXB Kim Đồng',
        14400,
        16000,
        10,
        20,
        0,
        N'/images/real/9786042394314.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14,5x20,5 cm',
        N'',
        N'https://nxbkimdong.com.vn/hat-mam-nhan-cach-nuoi-duong-long-nhan-hau-trai-tim-nguoi-me-26'
    ),
    (
        N'9786042374323',
        N'Thưởng thức triết học - Máy móc và con người',
        N'Một tập trong bộ Thưởng thức triết học, xoay quanh mối quan hệ giữa con người và máy móc.

Tác giả: Brigitte Labbé; P-F Dupont-Beurie; Jacques Azam. Nhà xuất bản Kim Đồng. 40 trang, bìa mềm.',
        N'Kiến thức - khoa học',
        N'Brigitte Labbé; P-F Dupont-Beurie; Jacques Azam',
        N'NXB Kim Đồng',
        22500,
        25000,
        8,
        40,
        0,
        N'/images/real/9786042374323.jpg',
        N'PDF:https://bizweb.dktcdn.net/100/576/749/files/preview_thuong_thuc_triet_hoc_-_may_moc_va_con_nguoi.pdf?v=1788068843160',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'13x19 cm',
        N'',
        N'https://nxbkimdong.com.vn/thuong-thuc-triet-hoc-may-moc-va-con-nguoi-26'
    ),
    (
        N'9786042263986',
        N'Một đêm giông bão - Tập 1',
        N'Tập mở đầu câu chuyện về hai người bạn khác loài trong một đêm bão.

Tác giả: Yuichi Kimura; Thùy Cốm. Nhà xuất bản Kim Đồng. 92 trang, bìa mềm.',
        N'Văn học nước ngoài',
        N'Yuichi Kimura; Thùy Cốm',
        N'NXB Kim Đồng',
        27000,
        30000,
        10,
        92,
        0,
        N'/images/real/9786042263986.jpg',
        N'PDF:https://file.hstatic.net/200000343865/file/preview_mot_dem_giong_bao_tap_1.pdf',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'13x19 cm',
        N'',
        N'https://nxbkimdong.com.vn/mot-dem-giong-bao-tap-1-26'
    ),
    (
        N'9786042425728',
        N'Có một con chó bay qua nóc nhà',
        N'Những câu chuyện của Trần Đức Tiến hướng tới đời sống trẻ thơ và sự gắn bó với thiên nhiên.

Tác giả: Trần Đức Tiến; Kim Duẩn. Nhà xuất bản Kim Đồng. 132 trang, bìa mềm.',
        N'Văn học Việt Nam',
        N'Trần Đức Tiến; Kim Duẩn',
        N'NXB Kim Đồng',
        121500,
        135000,
        6,
        132,
        0,
        N'/images/real/9786042425728.jpg',
        N'PDF:https://bizweb.dktcdn.net/100/576/749/files/co_mot_con_cho_bay_qua_noc_nha_preview.pdf?v=1793180979350',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'18x25 cm',
        N'',
        N'https://nxbkimdong.com.vn/co-mot-con-cho-bay-qua-noc-nha'
    ),
    (
        N'9786042393393',
        N'Fullmetal Alchemist - Cang giả kim thuật sư - Hợp tuyển kỉ niệm 20 năm',
        N'Hợp tuyển các truyện ngắn cùng chia sẻ của những người góp phần tạo nên Fullmetal Alchemist.

Tác giả: Hiromu Arakawa. Nhà xuất bản Kim Đồng. 244 trang, bìa mềm.',
        N'Manga - comic',
        N'Hiromu Arakawa',
        N'NXB Kim Đồng',
        62100,
        69000,
        18,
        244,
        0,
        N'/images/real/9786042393393.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'13x18 cm',
        N'',
        N'https://nxbkimdong.com.vn/fullmetal-alchemist-cang-gia-kim-thuat-su-hop-tuyen-ki-niem-20-nam-26'
    ),
    (
        N'9786042382045',
        N'Hồi kí về Bác Hồ - Gần bên Bác và học ở Bác',
        N'Những hồi ức của người từng công tác, bảo vệ và làm việc gần Chủ tịch Hồ Chí Minh.

Tác giả: Nhiều tác giả. Nhà xuất bản Kim Đồng. 168 trang, bìa mềm.',
        N'Lịch sử - truyền thống',
        N'Nhiều tác giả',
        N'NXB Kim Đồng',
        36000,
        40000,
        17,
        168,
        0,
        N'/images/real/9786042382045.jpg',
        N'PDF:https://bizweb.dktcdn.net/100/576/749/files/preview_gan_ben_bac_va_hoc_o_bac.pdf?v=1784876380237',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'13x19 cm',
        N'',
        N'https://nxbkimdong.com.vn/hoi-ki-ve-bac-ho-gan-ben-bac-va-hoc-o-bac-26'
    ),
    (
        N'9786042283304',
        N'Hồ sơ tâm lí tội phạm - Tập 5',
        N'Tập kết thúc của loạt sách khai thác động cơ và tâm lí phía sau hành vi phạm tội.

Tác giả: Cương Tuyết Ấn. Nhà xuất bản Kim Đồng. 400 trang, bìa mềm.',
        N'Wings Books',
        N'Cương Tuyết Ấn',
        N'NXB Kim Đồng',
        126000,
        140000,
        5,
        400,
        0,
        N'/images/real/9786042283304.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14x22.5 cm',
        N'',
        N'https://nxbkimdong.com.vn/ho-so-tam-li-toi-pham-tap-5-26'
    ),
    (
        N'9786042305969',
        N'Không sao đâu con! - Thua cuộc thì có sao!',
        N'Giúp trẻ nhìn nhận thất bại, nhận ra điểm mạnh của mình và sẵn lòng học hỏi.

Tác giả: Trần Tuấn Hồng. Nhà xuất bản Kim Đồng. 24 trang, bìa mềm.',
        N'Truyện tranh',
        N'Trần Tuấn Hồng',
        N'NXB Kim Đồng',
        29700,
        33000,
        10,
        24,
        0,
        N'/images/real/9786042305969.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'21x23 cm',
        N'',
        N'https://nxbkimdong.com.vn/khong-sao-dau-con-thua-cuoc-thi-co-sao-26'
    ),
    (
        N'9786042036238',
        N'Từ điển hình ảnh cho bé - Động vật',
        N'Sách từ điển dùng hình ảnh để giới thiệu thế giới động vật cho bạn đọc nhỏ tuổi.

Tác giả: Lê Bích Thủy; Hiếu Minh. Nhà xuất bản Kim Đồng. 12 trang, sách carton.',
        N'Kiến thức - khoa học',
        N'Lê Bích Thủy; Hiếu Minh',
        N'NXB Kim Đồng',
        27000,
        30000,
        8,
        12,
        0,
        N'/images/real/9786042036238.jpg',
        N'',
        N'Tiếng Việt',
        N'Sách carton',
        N'12,5x12,5 cm',
        N'',
        N'https://nxbkimdong.com.vn/tu-dien-hinh-anh-cho-be-dong-vat-26'
    ),
    (
        N'9786042377393',
        N'Truyện cổ Grimm - Tập 2',
        N'Tuyển truyện dân gian do anh em Grimm sưu tầm, được giới thiệu trong tập thứ hai.

Tác giả: Jacob Grimm; Wilhelm Grimm. Nhà xuất bản Kim Đồng. 348 trang, bìa mềm.',
        N'Văn học nước ngoài',
        N'Jacob Grimm; Wilhelm Grimm',
        N'NXB Kim Đồng',
        58500,
        65000,
        10,
        348,
        0,
        N'/images/real/9786042377393.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'13x19 cm',
        N'',
        N'https://nxbkimdong.com.vn/truyen-co-grimm-tap-2-26'
    ),
    (
        N'9786042422383',
        N'Hành trình yêu thương nối dài - Nhật kí Thiện Nhân 2',
        N'Những ghi chép tiếp nối hành trình trưởng thành của Thiện Nhân và các hoạt động hỗ trợ trẻ em.

Tác giả: Trần Mai Anh. Nhà xuất bản Kim Đồng. 280 trang, bìa mềm.',
        N'Văn học Việt Nam',
        N'Trần Mai Anh',
        N'NXB Kim Đồng',
        72000,
        80000,
        470,
        280,
        0,
        N'/images/real/9786042422383.jpg',
        N'PDF:https://bizweb.dktcdn.net/100/576/749/files/hanh_trinh_yeu_thuong_noi_dai_nhat_ki_thien_nhan_2_preview.pdf?v=1793014123297',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14.5x20.5 cm',
        N'',
        N'https://nxbkimdong.com.vn/hanh-trinh-yeu-thuong-noi-dai-nhat-ki-thien-nhan-2'
    ),
    (
        N'9786042054973',
        N'Doraemon Tranh truyện màu - Năm 2112 Doraemon ra đời',
        N'Câu chuyện trở về thời Doraemon còn ở trường robot, trước khi đến sống cùng Nobita.

Tác giả: Fujiko F Fujio. Nhà xuất bản Kim Đồng. 128 trang, bìa mềm.',
        N'Manga - comic',
        N'Fujiko F Fujio',
        N'NXB Kim Đồng',
        27000,
        30000,
        20,
        128,
        0,
        N'/images/real/9786042054973.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'12.5x17.6 cm',
        N'',
        N'https://nxbkimdong.com.vn/doraemon-tranh-truyen-mau-nam-2112-doraemon-ra-doi-26'
    ),
    (
        N'9786042418232',
        N'Các triều đại Việt Nam',
        N'Một cách tiếp cận lịch sử Việt Nam qua trình tự các triều đại và những vị vua.

Tác giả: Đỗ Đức Hùng; Quỳnh Cư. Nhà xuất bản Kim Đồng. 384 trang, bìa mềm.',
        N'Lịch sử - truyền thống',
        N'Đỗ Đức Hùng; Quỳnh Cư',
        N'NXB Kim Đồng',
        108000,
        120000,
        10,
        384,
        0,
        N'/images/real/9786042418232.jpg',
        N'PDF:https://bizweb.dktcdn.net/100/576/749/files/cac_trieu_dai_viet_nam_preview.pdf?v=1792578124127',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14,5x20,5 cm',
        N'',
        N'https://nxbkimdong.com.vn/cac-trieu-dai-viet-nam'
    ),
    (
        N'9786042418485',
        N'Chuyện đời Ngưu Thiên Tứ',
        N'Ngưu Thiên Tứ lớn lên trong một gia đình nhận nuôi, giữa nhiều kì vọng và sự lạnh nhạt.

Tác giả: Lão Xá. Nhà xuất bản Kim Đồng. 256 trang, bìa mềm.',
        N'Wings Books',
        N'Lão Xá',
        N'NXB Kim Đồng',
        81000,
        90000,
        30,
        256,
        0,
        N'/images/real/9786042418485.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14x22,5 cm',
        N'',
        N'https://nxbkimdong.com.vn/chuyen-doi-nguu-thien-tu'
    ),
    (
        N'9786042184908',
        N'Ngôi nhà yêu thương - Cháu yêu bà',
        N'Thơ và tranh giúp trẻ bày tỏ tình cảm dành cho bà và các thành viên trong gia đình.

Tác giả: Nhiều tác giả. Nhà xuất bản Kim Đồng. 16 trang, sách carton.',
        N'Truyện tranh',
        N'Nhiều tác giả',
        N'NXB Kim Đồng',
        43200,
        48000,
        10,
        16,
        0,
        N'/images/real/9786042184908.jpg',
        N'',
        N'Tiếng Việt',
        N'Sách carton',
        N'15.5x20.5 cm',
        N'',
        N'https://nxbkimdong.com.vn/ngoi-nha-yeu-thuong-chau-yeu-ba-25'
    ),
    (
        N'9786042368643',
        N'Mười vạn câu hỏi vì sao - Phiên bản mới - Thế giới động vật',
        N'Những câu hỏi và lời giải thích về các loài vật trong bộ sách kiến thức dành cho thiếu nhi.

Tác giả: Dư Diệu Đông. Nhà xuất bản Kim Đồng. 72 trang, bìa mềm.',
        N'Kiến thức - khoa học',
        N'Dư Diệu Đông',
        N'NXB Kim Đồng',
        45000,
        50000,
        10,
        72,
        0,
        N'/images/real/9786042368643.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'18,5x20,5 cm',
        N'',
        N'https://nxbkimdong.com.vn/muoi-van-cau-hoi-vi-sao-phien-ban-moi-the-gioi-dong-vat-26'
    ),
    (
        N'9786042354660',
        N'Sinh vật thần thoại khắp thế gian',
        N'Các câu chuyện về sinh vật huyền thoại được tập hợp từ nhiều nền văn hóa trên thế giới.

Tác giả: Epic. Nhà xuất bản Kim Đồng. 252 trang, bìa mềm.',
        N'Văn học nước ngoài',
        N'Epic',
        N'NXB Kim Đồng',
        71100,
        79000,
        9,
        252,
        0,
        N'/images/real/9786042354660.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14.5x20.5 cm',
        N'',
        N'https://nxbkimdong.com.vn/sinh-vat-than-thoai-khap-the-gian-26'
    ),
    (
        N'9786042425520',
        N'Từ đất Tiền Giang',
        N'Đoàn Giỏi ghi lại cuộc đời hoạt động của Nguyễn Thị Thập qua những lời kể hồi kí.

Tác giả: Nguyễn Thị Thập; Đoàn Giỏi; . Nhà xuất bản Kim Đồng. 500 trang, bìa mềm.',
        N'Văn học Việt Nam',
        N'Nguyễn Thị Thập; Đoàn Giỏi; ',
        N'NXB Kim Đồng',
        121500,
        135000,
        10,
        500,
        0,
        N'/images/real/9786042425520.jpg',
        N'PDF:https://bizweb.dktcdn.net/100/576/749/files/tu_dat_tien_giang_preview.pdf?v=1792582207613',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14,5x20,5 cm',
        N'',
        N'https://nxbkimdong.com.vn/tu-dat-tien-giang'
    ),
    (
        N'9786042043243',
        N'Doraemon Tranh truyện màu - Đội quân Doraemon - Siêu đạo chích Dorapan và lá thư thách đấu',
        N'Đội quân Doraemon nhận lời cầu cứu rồi vướng vào cái bẫy do đạo chích Dorapan giăng ra.

Tác giả: Fujiko F Fujio. Nhà xuất bản Kim Đồng. 128 trang, bìa mềm.',
        N'Manga - comic',
        N'Fujiko F Fujio',
        N'NXB Kim Đồng',
        27000,
        30000,
        18,
        128,
        0,
        N'/images/real/9786042043243.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'12.5x17.6 cm',
        N'',
        N'https://nxbkimdong.com.vn/doraemon-tranh-truyen-mau-doi-quan-doraemon-sieu-dao-chich-dorapan-va-la-thu-thach-dau-26'
    ),
    (
        N'9786042421676',
        N'Tranh truyện lịch sử Việt Nam - Lê Quý Đôn',
        N'Cuộc đời và việc học của Lê Quý Đôn được giới thiệu qua tranh truyện dành cho thiếu nhi.

Tác giả: Lê Minh Hải; Hiếu Minh. Nhà xuất bản Kim Đồng. 32 trang, bìa mềm.',
        N'Lịch sử - truyền thống',
        N'Lê Minh Hải; Hiếu Minh',
        N'NXB Kim Đồng',
        18000,
        20000,
        6,
        32,
        0,
        N'/images/real/9786042421676.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14,5x20,5 cm',
        N'',
        N'https://nxbkimdong.com.vn/tranh-truyen-lich-su-viet-nam-le-quy-don'
    ),
    (
        N'9786042384704',
        N'Móng vuốt quạ đen (IV) - Giang hồ hiểm ác',
        N'Kaz Brekker cùng đồng đội phải tiếp tục tìm đường sống sau một phi vụ nguy hiểm.

Tác giả: Leigh Bardugo. Nhà xuất bản Kim Đồng. 324 trang, bìa mềm.',
        N'Wings Books',
        N'Leigh Bardugo',
        N'NXB Kim Đồng',
        108000,
        120000,
        10,
        324,
        0,
        N'/images/real/9786042384704.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14x22.5 cm',
        N'',
        N'https://nxbkimdong.com.vn/mong-vuot-qua-den-iv-giang-ho-hiem-ac-26'
    ),
    (
        N'9786042140089',
        N'Ngôi nhà yêu thương - Con yêu Mẹ',
        N'Một cuốn trong bộ Ngôi nhà yêu thương, dành cho tình cảm giữa trẻ nhỏ và mẹ.

Tác giả: Nhiều tác giả. Nhà xuất bản Kim Đồng. 16 trang, sách carton.',
        N'Truyện tranh',
        N'Nhiều tác giả',
        N'NXB Kim Đồng',
        43200,
        48000,
        10,
        16,
        0,
        N'/images/real/9786042140089.jpg',
        N'',
        N'Tiếng Việt',
        N'Sách carton',
        N'15.5x20 cm',
        N'',
        N'https://nxbkimdong.com.vn/ngoi-nha-yeu-thuong-con-yeu-me-26'
    ),
    (
        N'9786042423038',
        N'Ảo tưởng về sự bận rộn - Sự bận rộn và khối lượng công việc thực ra không liên quan nhiều đến nhau',
        N'Đặt lại câu hỏi về cảm giác luôn bận rộn và cách nhìn của chúng ta đối với thời gian.

Tác giả: Toyodome Natsumi. Nhà xuất bản Kim Đồng. 132 trang, bìa mềm.',
        N'Kiến thức - khoa học',
        N'Toyodome Natsumi',
        N'NXB Kim Đồng',
        40500,
        45000,
        6,
        132,
        0,
        N'/images/real/9786042423038.jpg',
        N'PDF:https://bizweb.dktcdn.net/100/576/749/files/ao_tuong_ve_su_ban_ron_preview.pdf?v=1793180979350',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14,5x20,5 cm',
        N'',
        N'https://nxbkimdong.com.vn/ao-tuong-ve-su-ban-ron-su-ban-ron-va-khoi-luong-cong-viec-thuc-ra-khong-lien-quan-nhieu-den-nhau'
    ),
    (
        N'9786042247719',
        N'Sinh nhật ở rừng và những cuộc vui tưng bừng',
        N'Những câu chuyện tưởng tượng về các loài vật, với phần minh họa của Jessica Ahlberg.

Tác giả: Toon Tellegen; Jessica Ahlberg. Nhà xuất bản Kim Đồng. 148 trang, bìa mềm.',
        N'Văn học nước ngoài',
        N'Toon Tellegen; Jessica Ahlberg',
        N'NXB Kim Đồng',
        49500,
        55000,
        8,
        148,
        0,
        N'/images/real/9786042247719.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'13 x19 cm',
        N'',
        N'https://nxbkimdong.com.vn/sinh-nhat-o-rung-va-nhung-cuoc-vui-tung-bung-26'
    ),
    (
        N'9786042422826',
        N'Lều chõng - Việc làng',
        N'Tập sách giới thiệu hai tác phẩm của Ngô Tất Tố về chuyện học hành và đời sống làng quê.

Tác giả: Ngô Tất Tố. Nhà xuất bản Kim Đồng. 460 trang, bìa mềm.',
        N'Văn học Việt Nam',
        N'Ngô Tất Tố',
        N'NXB Kim Đồng',
        139500,
        155000,
        9,
        460,
        0,
        N'/images/real/9786042422826.png',
        N'PDF:https://bizweb.dktcdn.net/100/576/749/files/leu_chong_viec_lang_preview.pdf?v=1792582207613',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14x22,5 cm',
        N'',
        N'https://nxbkimdong.com.vn/leu-chong-viec-lang'
    ),
    (
        N'9786042264891',
        N'Thám tử lừng danh Conan - Hoạt hình màu - Tàu ngầm sắt màu đen - Tập 2',
        N'Haibara cùng Naomi mắc kẹt trong kế hoạch khai thác công nghệ nhận diện của Tổ chức Áo đen.

Tác giả: Gosho Aoyama; Takeharu Sakurai. Nhà xuất bản Kim Đồng. 208 trang, bìa mềm.',
        N'Manga - comic',
        N'Gosho Aoyama; Takeharu Sakurai',
        N'NXB Kim Đồng',
        54000,
        60000,
        17,
        208,
        0,
        N'/images/real/9786042264891.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'13x18 cm',
        N'',
        N'https://nxbkimdong.com.vn/tham-tu-lung-danh-conan-hoat-hinh-mau-tau-ngam-sat-mau-den-tap-2-26'
    ),
    (
        N'9786042383134',
        N'Rèn nhân cách - Luyện tài năng - Bác Hồ - Tấm gương giản dị',
        N'Những câu chuyện về lối sống giản dị của Chủ tịch Hồ Chí Minh trong bộ sách rèn nhân cách.

Tác giả: Tạ Văn Sang. Nhà xuất bản Kim Đồng. 108 trang, bìa mềm.',
        N'Lịch sử - truyền thống',
        N'Tạ Văn Sang',
        N'NXB Kim Đồng',
        25200,
        28000,
        11,
        108,
        0,
        N'/images/real/9786042383134.png',
        N'PDF:https://bizweb.dktcdn.net/100/576/749/files/preview_bac_ho_tam_guong_gian_di.pdf?v=1784777686957',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'13x19 cm',
        N'',
        N'https://nxbkimdong.com.vn/ren-nhan-cach-luyen-tai-nang-bac-ho-tam-guong-gian-di-26'
    ),
    (
        N'9786042384698',
        N'Móng vuốt quạ đen (III) - Mưu ma chước quỷ',
        N'Cuộc đấu trí của nhóm Kaz Brekker tiếp diễn sau khi phần thưởng cho phi vụ không đến như dự tính.

Tác giả: Leigh Bardugo. Nhà xuất bản Kim Đồng. 308 trang, bìa mềm.',
        N'Wings Books',
        N'Leigh Bardugo',
        N'NXB Kim Đồng',
        108000,
        120000,
        10,
        308,
        0,
        N'/images/real/9786042384698.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14x22.5 cm',
        N'',
        N'https://nxbkimdong.com.vn/mong-vuot-qua-den-iii-muu-ma-chuoc-quy-26'
    ),
    (
        N'9786042037402',
        N'Chuột Típ - Típ ơi, đừng sợ!',
        N'Những sinh hoạt gần gũi của Chuột Típ giúp trẻ nhận diện nỗi sợ và tập cách ứng xử.

Tác giả: Marco Campanella; Anna Casalis. Nhà xuất bản Kim Đồng. 28 trang, bìa mềm.',
        N'Truyện tranh',
        N'Marco Campanella; Anna Casalis',
        N'NXB Kim Đồng',
        22500,
        25000,
        9,
        28,
        0,
        N'/images/real/9786042037402.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'18.5x20.5 cm',
        N'',
        N'https://nxbkimdong.com.vn/chuot-tip-tip-oi-dung-so-26'
    ),
    (
        N'9786042368872',
        N'Kĩ năng vàng cho học sinh trung học - Học cách trưởng thành',
        N'Lời khuyên cho bạn đọc trung học trước những thay đổi tâm lí của hành trình trưởng thành.

Tác giả: Liu Xuan. Nhà xuất bản Kim Đồng. 176 trang, bìa mềm.',
        N'Kiến thức - khoa học',
        N'Liu Xuan',
        N'NXB Kim Đồng',
        41400,
        46000,
        8,
        176,
        0,
        N'/images/real/9786042368872.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14,5x20,5 cm',
        N'',
        N'https://nxbkimdong.com.vn/ki-nang-vang-cho-hoc-sinh-trung-hoc-hoc-cach-truong-thanh-26'
    ),
    (
        N'9786042247733',
        N'Những lá thư nhờ gió gửi ai đó',
        N'Các loài vật trong thế giới của Toon Tellegen gửi những lá thư vượt khỏi giới hạn đời thường.

Tác giả: Toon Tellegen; Jessica Ahlberg. Nhà xuất bản Kim Đồng. 156 trang, bìa mềm.',
        N'Văn học nước ngoài',
        N'Toon Tellegen; Jessica Ahlberg',
        N'NXB Kim Đồng',
        49500,
        55000,
        9,
        156,
        0,
        N'/images/real/9786042247733.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'13x19 cm',
        N'',
        N'https://nxbkimdong.com.vn/nhung-la-thu-nho-gio-gui-ai-do-26'
    ),
    (
        N'9786042422819',
        N'Cạm bẫy người - Kỹ nghệ lấy Tây - Cơm thầy cơm cô',
        N'Ba tác phẩm phóng sự của Vũ Trọng Phụng đặt cạnh nhau trong một tập sách.

Tác giả: Vũ Trọng Phụng. Nhà xuất bản Kim Đồng. 308 trang, bìa mềm.',
        N'Văn học Việt Nam',
        N'Vũ Trọng Phụng',
        N'NXB Kim Đồng',
        103500,
        115000,
        7,
        308,
        0,
        N'/images/real/9786042422819.jpg',
        N'PDF:https://bizweb.dktcdn.net/100/576/749/files/cam_bay_nguoi_ky_nghe_lay_tay_com_thay_com_co_preview.pdf?v=1792582207613',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14x22,5 cm',
        N'',
        N'https://nxbkimdong.com.vn/cam-bay-nguoi-ky-nghe-lay-tay-com-thay-com-co'
    ),
    (
        N'9786042264860',
        N'Thám tử lừng danh Conan - Hoạt hình màu - Tàu ngầm sắt màu đen - Tập 1',
        N'Conan đến đảo Hachijo giữa lúc một hệ thống kết nối camera quốc tế trở thành mục tiêu nguy hiểm.

Tác giả: Gosho Aoyama; Takeharu Sakurai. Nhà xuất bản Kim Đồng. 208 trang, bìa mềm.',
        N'Manga - comic',
        N'Gosho Aoyama; Takeharu Sakurai',
        N'NXB Kim Đồng',
        54000,
        60000,
        17,
        208,
        0,
        N'/images/real/9786042264860.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'13x18 cm',
        N'',
        N'https://nxbkimdong.com.vn/tham-tu-lung-danh-conan-hoat-hinh-mau-tau-ngam-sat-mau-den-tap-1-26'
    ),
    (
        N'9786042383172',
        N'Rèn nhân cách - Luyện tài năng - Bác Hồ - Tấm gương đoàn kết',
        N'Chủ đề đoàn kết được trình bày trong bộ sách kể chuyện về tấm gương Chủ tịch Hồ Chí Minh.

Tác giả: Phạm Văn Hòa. Nhà xuất bản Kim Đồng. 120 trang, bìa mềm.',
        N'Lịch sử - truyền thống',
        N'Phạm Văn Hòa',
        N'NXB Kim Đồng',
        27000,
        30000,
        15,
        120,
        0,
        N'/images/real/9786042383172.png',
        N'PDF:https://bizweb.dktcdn.net/100/576/749/files/preview_bac_ho_tam_guong_doan_ket.pdf?v=1784777552850',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'13x19 cm',
        N'',
        N'https://nxbkimdong.com.vn/ren-nhan-cach-luyen-tai-nang-bac-ho-tam-guong-doan-ket-26'
    ),
    (
        N'9786042384681',
        N'Móng vuốt quạ đen (II) - Phi vụ bất khả',
        N'Kaz Brekker tập hợp một nhóm cộng sự cho vụ đột nhập có phần thưởng lớn nhưng đầy rủi ro.

Tác giả: Leigh Bardugo. Nhà xuất bản Kim Đồng. 248 trang, bìa mềm.',
        N'Wings Books',
        N'Leigh Bardugo',
        N'NXB Kim Đồng',
        90000,
        100000,
        9,
        248,
        0,
        N'/images/real/9786042384681.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14x22.5 cm',
        N'',
        N'https://nxbkimdong.com.vn/mong-vuot-qua-den-ii-phi-vu-bat-kha-26'
    ),
    (
        N'9786042361071',
        N'Tranh truyện dân gian Việt Nam - Hai ông tiến sĩ',
        N'Một truyện dân gian về nghĩa tình và lựa chọn của người phụ nữ khi gặp lại người chồng cũ.

Tác giả: Ngô Mạnh Lân; Hồng Hà. Nhà xuất bản Kim Đồng. 32 trang, bìa mềm.',
        N'Truyện tranh',
        N'Ngô Mạnh Lân; Hồng Hà',
        N'NXB Kim Đồng',
        18000,
        20000,
        10,
        32,
        0,
        N'/images/real/9786042361071.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14.5x20.5 cm',
        N'',
        N'https://nxbkimdong.com.vn/tranh-truyen-dan-gian-viet-nam-hai-ong-tien-si-26'
    ),
    (
        N'9786042363204',
        N'Bí ẩn thế giới loài vật - Cá',
        N'Cuốn sách thuộc bộ Bí ẩn thế giới loài vật, tập trung vào chủ đề các loài cá.

Tác giả: Phùng Duy Tùng; Thu Ngân. Nhà xuất bản Kim Đồng. 44 trang, bìa mềm.',
        N'Kiến thức - khoa học',
        N'Phùng Duy Tùng; Thu Ngân',
        N'NXB Kim Đồng',
        45000,
        50000,
        9,
        44,
        0,
        N'/images/real/9786042363204.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'20,5x20,5 cm',
        N'',
        N'https://nxbkimdong.com.vn/bi-an-the-gioi-loai-vat-ca-26'
    ),
    (
        N'9786042424349',
        N'Đài phát thanh Popov và những đứa trẻ bị lãng quên',
        N'Alfred tìm thấy sự quan tâm từ một người giao báo đặc biệt giữa cuộc sống tuổi thơ cô quạnh.

Tác giả: Anja Portin. Nhà xuất bản Kim Đồng. 280 trang, bìa mềm.',
        N'Văn học nước ngoài',
        N'Anja Portin',
        N'NXB Kim Đồng',
        76500,
        85000,
        7,
        280,
        0,
        N'/images/real/9786042424349.png',
        N'PDF:https://bizweb.dktcdn.net/100/576/749/files/dai_phat_thanh_popov_va_nhung_dua_tre_bi_lang_quen_preview.pdf?v=1792137739023',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'14,5x20,5 cm',
        N'',
        N'https://nxbkimdong.com.vn/dai-phat-thanh-popov-va-nhung-dua-tre-bi-lang-quen'
    ),
    (
        N'9786042423670',
        N'Phạm Hổ - Nhà thơ sống nhiều tuổi thơ',
        N'Giới thiệu cuộc đời và sáng tác của Phạm Hổ, tác giả gắn bó với văn học dành cho thiếu nhi.

Tác giả: Phạm Hổ. Nhà xuất bản Kim Đồng. 712 trang, bìa cứng.',
        N'Văn học Việt Nam',
        N'Phạm Hổ',
        N'NXB Kim Đồng',
        261000,
        290000,
        10,
        712,
        0,
        N'/images/real/9786042423670.jpg',
        N'PDF:https://bizweb.dktcdn.net/100/576/749/files/pham_ho_nha_tho_song_nhieu_tuoi_tho_preview.pdf?v=1792582207613',
        N'Tiếng Việt',
        N'Bìa cứng',
        N'16x24 cm',
        N'',
        N'https://nxbkimdong.com.vn/pham-ho-nha-tho-song-nhieu-tuoi-tho'
    ),
    (
        N'9786042043007',
        N'45 chương mở đầu bộ truyện ngắn Doraemon - Tập 2',
        N'Tuyển tập những chương mở đầu trong loạt truyện ngắn về Doraemon và Nobita.

Tác giả: Fujiko F Fujio. Nhà xuất bản Kim Đồng. 244 trang, bìa mềm.',
        N'Manga - comic',
        N'Fujiko F Fujio',
        N'NXB Kim Đồng',
        49500,
        55000,
        18,
        244,
        0,
        N'/images/real/9786042043007.jpg',
        N'',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'13x18 cm',
        N'',
        N'https://nxbkimdong.com.vn/45-chuong-mo-dau-bo-truyen-ngan-doraemon-tap-2-26'
    ),
    (
        N'9786042418997',
        N'Chiến dịch diệt chuột ở Hà Nội - Đế quốc, dịch bệnh và sự "hiện đại" ở Việt Nam thời Pháp thuộc',
        N'Khảo cứu chiến dịch diệt chuột ở Hà Nội đầu thế kỉ XX cùng bối cảnh đô thị thuộc địa.

Tác giả: Michael G. Vann; Liz Clarke. Nhà xuất bản Kim Đồng. 280 trang, bìa mềm.',
        N'Lịch sử - truyền thống',
        N'Michael G. Vann; Liz Clarke',
        N'NXB Kim Đồng',
        189000,
        210000,
        5,
        280,
        0,
        N'/images/real/9786042418997.jpg',
        N'PDF:https://bizweb.dktcdn.net/100/576/749/files/chien_dich_diet_chuot_o_ha_noi.pdf?v=1787918840790',
        N'Tiếng Việt',
        N'Bìa mềm',
        N'18 x 24 cm',
        N'',
        N'https://nxbkimdong.com.vn/chien-dich-diet-chuot-o-ha-noi-de-quoc-dich-benh-va-su-hien-dai-o-viet-nam-thoi-phap-thuoc'
    );
BEGIN TRY
    BEGIN TRANSACTION;

    INSERT INTO dbo.Categories(Name)
    SELECT DISTINCT c.CategoryName FROM @Catalog AS c
    WHERE NOT EXISTS (SELECT 1 FROM dbo.Categories WITH (UPDLOCK, HOLDLOCK) WHERE Name = c.CategoryName);
    INSERT INTO dbo.Authors(Name)
    SELECT DISTINCT c.AuthorName FROM @Catalog AS c
    WHERE NOT EXISTS (SELECT 1 FROM dbo.Authors WITH (UPDLOCK, HOLDLOCK) WHERE Name = c.AuthorName);
    INSERT INTO dbo.Publishers(Name)
    SELECT DISTINCT c.PublisherName FROM @Catalog AS c
    WHERE NOT EXISTS (SELECT 1 FROM dbo.Publishers WITH (UPDLOCK, HOLDLOCK) WHERE Name = c.PublisherName);

    -- Sach da co: cap nhat thong tin nguon, khong doi Stock va CreatedAt.
    UPDATE b SET
        Title = c.Title, Description = c.Description,
        CategoryId = category.Id, AuthorId = author.Id, PublisherId = publisher.Id,
        Price = c.Price, ListPrice = c.ListPrice, Pages = c.Pages, Year = c.Year,
        ImagePath = c.ImagePath, SampleText = c.SampleText, Language = c.Language,
        Binding = c.Binding, Dimensions = c.Dimensions, Translator = c.Translator,
        SourceUrl = c.SourceUrl, IsActive = 1
    FROM dbo.Books AS b
    JOIN @Catalog AS c ON c.Isbn = b.Isbn
    JOIN dbo.Categories AS category ON category.Name = c.CategoryName
    JOIN dbo.Authors AS author ON author.Name = c.AuthorName
    JOIN dbo.Publishers AS publisher ON publisher.Name = c.PublisherName;

    INSERT INTO dbo.Books (
        Title, Description, Isbn, CategoryId, AuthorId, PublisherId,
        Price, ListPrice, Stock, Pages, Year, ImagePath, SampleText, IsActive,
        Language, Binding, Dimensions, Translator, SourceUrl)
    SELECT c.Title, c.Description, c.Isbn, category.Id, author.Id, publisher.Id,
        c.Price, c.ListPrice, c.InitialStock, c.Pages, c.Year, c.ImagePath, c.SampleText, 1,
        c.Language, c.Binding, c.Dimensions, c.Translator, c.SourceUrl
    FROM @Catalog AS c
    JOIN dbo.Categories AS category ON category.Name = c.CategoryName
    JOIN dbo.Authors AS author ON author.Name = c.AuthorName
    JOIN dbo.Publishers AS publisher ON publisher.Name = c.PublisherName
    WHERE NOT EXISTS (SELECT 1 FROM dbo.Books WITH (UPDLOCK, HOLDLOCK) WHERE Isbn = c.Isbn);

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
PRINT N'Da dong bo 50 sach that. Tiep theo chay 09_danh_muc_50_sach.sql de don sach cu.';
