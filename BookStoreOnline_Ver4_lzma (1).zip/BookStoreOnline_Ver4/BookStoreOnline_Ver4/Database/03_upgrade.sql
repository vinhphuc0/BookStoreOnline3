﻿-- Database CU: chon dung database, chay file nay roi 07_mvc5_orders.sql.
-- Chi bo sung cot thong tin sach, khong ghi de du lieu da co.
SET NOCOUNT ON;
SET XACT_ABORT ON;
IF DB_NAME() IN (N'master', N'model', N'msdb', N'tempdb')
    THROW 51000, N'Hay chon database cua website.', 1;
BEGIN TRY
    BEGIN TRANSACTION;
    IF OBJECT_ID(N'dbo.Books', N'U') IS NULL
        THROW 51001, N'Chua co bang Books. Hay kiem tra database.', 1;
    IF COL_LENGTH(N'dbo.Books', N'Language') IS NULL
        ALTER TABLE dbo.Books ADD Language nvarchar(50) NOT NULL CONSTRAINT DF_Books_Language DEFAULT N'Tiếng Việt';
    IF COL_LENGTH(N'dbo.Books', N'Binding') IS NULL
        ALTER TABLE dbo.Books ADD Binding nvarchar(50) NOT NULL CONSTRAINT DF_Books_Binding DEFAULT N'Bìa mềm';
    IF COL_LENGTH(N'dbo.Books', N'Dimensions') IS NULL
        ALTER TABLE dbo.Books ADD Dimensions nvarchar(50) NOT NULL CONSTRAINT DF_Books_Dimensions DEFAULT N'';
    IF COL_LENGTH(N'dbo.Books', N'Translator') IS NULL
        ALTER TABLE dbo.Books ADD Translator nvarchar(150) NOT NULL CONSTRAINT DF_Books_Translator DEFAULT N'';
    IF COL_LENGTH(N'dbo.Books', N'SourceUrl') IS NULL
        ALTER TABLE dbo.Books ADD SourceUrl nvarchar(500) NOT NULL CONSTRAINT DF_Books_SourceUrl DEFAULT N'';
    IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.Books') AND name = N'IX_Books_Isbn')
        CREATE INDEX IX_Books_Isbn ON dbo.Books(Isbn);
    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
PRINT N'Da cap nhat thong tin sach. Tiep theo chay 07_mvc5_orders.sql.';
