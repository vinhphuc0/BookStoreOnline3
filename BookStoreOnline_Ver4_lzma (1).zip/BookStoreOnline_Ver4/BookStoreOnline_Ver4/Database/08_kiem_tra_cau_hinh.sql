﻿-- CHI DOC. Chon dung database cua website truoc khi chay.
SET NOCOUNT ON;
SELECT CONVERT(nvarchar(128), SERVERPROPERTY('ServerName')) AS SqlServer, DB_NAME() AS DatabaseDangDung;

-- Ket qua trong: cac cot can thiet cho EF6 da co, dung kieu va khong NULL.
DECLARE @Expected TABLE (TableName sysname, ColumnName sysname, SqlType sysname, MinBytes int);
INSERT INTO @Expected VALUES
    (N'Categories', N'Id', N'int', 0),
    (N'Categories', N'Name', N'nvarchar', 200),
    (N'Authors', N'Id', N'int', 0),
    (N'Authors', N'Name', N'nvarchar', 300),
    (N'Publishers', N'Id', N'int', 0),
    (N'Publishers', N'Name', N'nvarchar', 300),
    (N'Users', N'Id', N'int', 0),
    (N'Users', N'FullName', N'nvarchar', 200),
    (N'Users', N'Email', N'nvarchar', 508),
    (N'Users', N'PasswordHash', N'nvarchar', 1200),
    (N'Users', N'Role', N'nvarchar', 40),
    (N'Users', N'IsActive', N'bit', 0),
    (N'Users', N'CreatedAt', N'datetime2', 0),
    (N'Books', N'Language', N'nvarchar', 100),
    (N'Books', N'Binding', N'nvarchar', 100),
    (N'Books', N'Dimensions', N'nvarchar', 100),
    (N'Books', N'Translator', N'nvarchar', 300),
    (N'Books', N'SourceUrl', N'nvarchar', 1000),
    (N'Books', N'Id', N'int', 0),
    (N'Books', N'Title', N'nvarchar', 500),
    (N'Books', N'Description', N'nvarchar', -1),
    (N'Books', N'Isbn', N'nvarchar', 60),
    (N'Books', N'CategoryId', N'int', 0),
    (N'Books', N'AuthorId', N'int', 0),
    (N'Books', N'PublisherId', N'int', 0),
    (N'Books', N'Price', N'decimal', 0),
    (N'Books', N'ListPrice', N'decimal', 0),
    (N'Books', N'Stock', N'int', 0),
    (N'Books', N'Pages', N'int', 0),
    (N'Books', N'Year', N'int', 0),
    (N'Books', N'ImagePath', N'nvarchar', 600),
    (N'Books', N'SampleText', N'nvarchar', -1),
    (N'Books', N'IsActive', N'bit', 0),
    (N'Books', N'CreatedAt', N'datetime2', 0),
    (N'Orders', N'Id', N'int', 0),
    (N'Orders', N'CheckoutKey', N'nvarchar', 64),
    (N'Orders', N'UserId', N'int', 0),
    (N'Orders', N'Recipient', N'nvarchar', -1),
    (N'Orders', N'Phone', N'nvarchar', 40),
    (N'Orders', N'Address', N'nvarchar', -1),
    (N'Orders', N'Note', N'nvarchar', -1),
    (N'Orders', N'ShippingFee', N'decimal', 0),
    (N'Orders', N'Total', N'decimal', 0),
    (N'Orders', N'PaymentStatus', N'nvarchar', 60),
    (N'Orders', N'Status', N'nvarchar', 60),
    (N'Orders', N'PaymentMethod', N'nvarchar', 40),
    (N'Orders', N'CreatedAt', N'datetime2', 0),
    (N'OrderItems', N'Id', N'int', 0),
    (N'OrderItems', N'OrderId', N'int', 0),
    (N'OrderItems', N'BookId', N'int', 0),
    (N'OrderItems', N'BookTitle', N'nvarchar', 500),
    (N'OrderItems', N'Quantity', N'int', 0),
    (N'OrderItems', N'UnitPrice', N'decimal', 0);
SELECT e.TableName AS Bang, e.ColumnName AS Cot,
       e.SqlType AS KieuCanCo, TYPE_NAME(c.user_type_id) AS KieuHienTai,
       c.max_length AS DoDaiBytes, c.is_nullable AS ChoPhepNull
FROM @Expected AS e
LEFT JOIN sys.tables AS t ON t.name = e.TableName AND t.schema_id = SCHEMA_ID(N'dbo')
LEFT JOIN sys.columns AS c ON c.object_id = t.object_id AND c.name = e.ColumnName
WHERE c.column_id IS NULL OR TYPE_NAME(c.user_type_id) <> e.SqlType OR c.is_nullable = 1
   OR (e.MinBytes = -1 AND c.max_length <> -1)
   OR (e.MinBytes > 0 AND c.max_length <> -1 AND c.max_length < e.MinBytes)
   OR (e.SqlType = N'decimal' AND (c.precision <> 18 OR c.scale <> 0));

-- Ca hai quy tac phai co, dang bat va duoc SQL Server kiem tra.
SELECT expected.name AS QuyTac, cc.is_disabled AS BiTat, cc.is_not_trusted AS ChuaKiemTra
FROM (VALUES (N'CK_Orders_Status_MVC5'), (N'CK_Orders_PaymentStatus_MVC5')) AS expected(name)
LEFT JOIN sys.check_constraints AS cc
    ON cc.name = expected.name AND cc.parent_object_id = OBJECT_ID(N'dbo.Orders');

SELECT fk.name AS KhoaNgoai, OBJECT_NAME(fk.parent_object_id) AS BangCon,
       OBJECT_NAME(fk.referenced_object_id) AS BangCha, fk.is_disabled AS BiTat,
       fk.is_not_trusted AS ChuaKiemTra
FROM sys.foreign_keys AS fk
WHERE fk.schema_id = SCHEMA_ID(N'dbo');

IF OBJECT_ID(N'dbo.Books', N'U') IS NOT NULL
    EXEC sys.sp_executesql N'SELECT COUNT(*) AS TongSoSach FROM dbo.Books;';
IF COL_LENGTH(N'dbo.Users', N'Role') IS NOT NULL AND COL_LENGTH(N'dbo.Users', N'IsActive') IS NOT NULL
    EXEC sys.sp_executesql N'SELECT COUNT(*) AS SoAdminHoatDong FROM dbo.Users WHERE Role = N''Admin'' AND IsActive = 1;';

-- Chi bao cao ISBN trung, khong tu xoa sach co lich su don hang.
IF COL_LENGTH(N'dbo.Books', N'Isbn') IS NOT NULL
    EXEC sys.sp_executesql N'
        SELECT LTRIM(RTRIM(Isbn)) AS IsbnTrung, COUNT(*) AS SoBanGhi
        FROM dbo.Books
        GROUP BY LTRIM(RTRIM(Isbn))
        HAVING COUNT(*) > 1;';
