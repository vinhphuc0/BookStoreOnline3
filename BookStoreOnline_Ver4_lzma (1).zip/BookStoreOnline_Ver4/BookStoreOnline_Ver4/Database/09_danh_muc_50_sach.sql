﻿-- Sao luu truoc. Giu 50 ISBN duoc chon; khong xoa sach da nam trong don hang.
-- Sach cu KHONG co don hang se bi xoa; sach co lich su chi ngung ban.
SET NOCOUNT ON;
SET XACT_ABORT ON;
IF DB_NAME() IN (N'master', N'model', N'msdb', N'tempdb')
    THROW 51000, N'Hay chon database cua website.', 1;
DECLARE @Wanted TABLE (Isbn nvarchar(30) PRIMARY KEY);
INSERT INTO @Wanted VALUES
    (N'9786042037310'),
    (N'9786042374330'),
    (N'9786042263993'),
    (N'9786042378864'),
    (N'9786042425650'),
    (N'9786042034838'),
    (N'9786042418492'),
    (N'9786042346993'),
    (N'9786042422345'),
    (N'9786042394314'),
    (N'9786042374323'),
    (N'9786042263986'),
    (N'9786042425728'),
    (N'9786042393393'),
    (N'9786042382045'),
    (N'9786042283304'),
    (N'9786042305969'),
    (N'9786042036238'),
    (N'9786042377393'),
    (N'9786042422383'),
    (N'9786042054973'),
    (N'9786042418232'),
    (N'9786042418485'),
    (N'9786042184908'),
    (N'9786042368643'),
    (N'9786042354660'),
    (N'9786042425520'),
    (N'9786042043243'),
    (N'9786042421676'),
    (N'9786042384704'),
    (N'9786042140089'),
    (N'9786042423038'),
    (N'9786042247719'),
    (N'9786042422826'),
    (N'9786042264891'),
    (N'9786042383134'),
    (N'9786042384698'),
    (N'9786042037402'),
    (N'9786042368872'),
    (N'9786042247733'),
    (N'9786042422819'),
    (N'9786042264860'),
    (N'9786042383172'),
    (N'9786042384681'),
    (N'9786042361071'),
    (N'9786042363204'),
    (N'9786042424349'),
    (N'9786042423670'),
    (N'9786042043007'),
    (N'9786042418997');
BEGIN TRY
    BEGIN TRANSACTION;
    DECLARE @Keep TABLE (Id int PRIMARY KEY);
    INSERT INTO @Keep(Id)
    SELECT MIN(b.Id)
    FROM dbo.Books AS b WITH (UPDLOCK, HOLDLOCK)
    JOIN @Wanted AS w ON w.Isbn = b.Isbn
    WHERE b.SourceUrl LIKE N'https://nxbkimdong.com.vn/%'
      AND b.ImagePath LIKE N'/images/real/%'
    GROUP BY b.Isbn;
    IF (SELECT COUNT(*) FROM @Keep) <> 50
        THROW 51009, N'Chua du 50 sach that. Chay 02_seed.sql truoc.', 1;

    UPDATE dbo.Books SET IsActive = CASE WHEN Id IN (SELECT Id FROM @Keep) THEN 1 ELSE 0 END;
    DELETE b FROM dbo.Books AS b
    WHERE b.Id NOT IN (SELECT Id FROM @Keep)
      AND NOT EXISTS (SELECT 1 FROM dbo.OrderItems AS item WHERE item.BookId = b.Id);

    -- Don cac danh muc cu khong con sach su dung.
    DELETE FROM dbo.Authors WHERE NOT EXISTS (SELECT 1 FROM dbo.Books WHERE AuthorId = dbo.Authors.Id);
    DELETE FROM dbo.Categories WHERE NOT EXISTS (SELECT 1 FROM dbo.Books WHERE CategoryId = dbo.Categories.Id);
    DELETE FROM dbo.Publishers WHERE NOT EXISTS (SELECT 1 FROM dbo.Books WHERE PublisherId = dbo.Publishers.Id);

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;
SELECT COUNT(*) AS SoSachDangBan FROM dbo.Books WHERE IsActive = 1;
