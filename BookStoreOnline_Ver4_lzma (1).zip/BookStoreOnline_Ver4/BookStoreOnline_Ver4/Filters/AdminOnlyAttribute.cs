﻿using System.Web.Mvc;
using System.Web.Routing;

namespace BookStoreOnline.Filters
{
    // Chưa đăng nhập: về Login. Đã đăng nhập nhưng sai quyền: hiện trang từ chối.
    public class AdminOnlyAttribute : AuthorizeAttribute
    {
        public AdminOnlyAttribute()
        {
            Roles = "Admin";
        }

        protected override void HandleUnauthorizedRequest(AuthorizationContext context)
        {
            if (!context.HttpContext.User.Identity.IsAuthenticated)
            {
                base.HandleUnauthorizedRequest(context);
                return;
            }

            context.Result = new RedirectToRouteResult(new RouteValueDictionary(new { area = "", controller = "Account", action = "AccessDenied" }));
        }
    }
}
