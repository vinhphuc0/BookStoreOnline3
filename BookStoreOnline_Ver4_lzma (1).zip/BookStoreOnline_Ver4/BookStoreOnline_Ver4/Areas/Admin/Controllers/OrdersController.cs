﻿using System;
using System.Linq;
using System.Data;
using System.Data.Entity;
using System.Web.Mvc;
using BookStoreOnline.Controllers;
using BookStoreOnline.ViewModels;
using BookStoreOnline.Services;

namespace BookStoreOnline.Areas.Admin.Controllers
{
    [BookStoreOnline.Filters.AdminOnly]
    // Controller nhận yêu cầu, kiểm tra dữ liệu và trả View tương ứng.
    public class OrdersController : BaseController
    {
        // Lọc trước, đếm tổng, rồi Skip/Take để phân trang 15 đơn.
        public ActionResult Index(string q, string status, string payment, DateTime? from, DateTime? to, string sort = "new", int page = 1)
        {
            if (!OrderSchemaReady())
            {
                return OrderSetupRequired();
            }

            // 1. Bỏ khoảng trắng, giới hạn độ dài từ khóa.
            if (string.IsNullOrWhiteSpace(q))
            {
                q = null;
            }
            else
            {
                q = q.Trim();
                if (q.Length > 120)
                {
                    q = q.Substring(0, 120);
                }
            }

            // 2. Chỉ tạo truy vấn; ToList bên dưới mới lấy dữ liệu.
            var rows = db.Orders.AsNoTracking().Include(x => x.User);
            if (q != null)
            {
                int orderId;
                bool searchById = OrderRules.TryId(q, out orderId);
                rows = rows.Where(x => (searchById && x.Id == orderId) || x.User.FullName.Contains(q) || x.Recipient.Contains(q));
            }

            if (OrderRules.Statuses.Contains(status))
            {
                rows = rows.Where(x => x.Status == status);
            }
            else
            {
                status = null;
            }

            if (OrderRules.Payments.Contains(payment))
            {
                rows = rows.Where(x => x.PaymentStatus == payment);
            }
            else
            {
                payment = null;
            }

            if (from.HasValue && to.HasValue && from > to)
            {
                var tmp = from;
                from = to;
                to = tmp;
            }

            if (from.HasValue)
            {
                var start = from.Value.Date.AddHours(-7);
                rows = rows.Where(x => x.CreatedAt >= start);
            }

            if (to.HasValue)
            {
                var end = to.Value.Date.AddDays(1).AddHours(-7);
                rows = rows.Where(x => x.CreatedAt < end);
            }

            switch (sort)
            {
                case "old":
                    rows = rows.OrderBy(x => x.CreatedAt).ThenBy(x => x.Id);
                    break;
                case "total-desc":
                    rows = rows.OrderByDescending(x => x.Total).ThenByDescending(x => x.Id);
                    break;
                case "total-asc":
                    rows = rows.OrderBy(x => x.Total).ThenBy(x => x.Id);
                    break;
                default:
                    sort = "new";
                    rows = rows.OrderByDescending(x => x.CreatedAt).ThenByDescending(x => x.Id);
                    break;
            }

            int total = rows.Count();
            // 3. Mỗi trang 15 đơn. Không cho vượt ngoài số trang hiện có.
            int pageCount = (int)Math.Ceiling(total / 15.0);
            if (pageCount < 1)
            {
                pageCount = 1;
            }

            if (page < 1)
            {
                page = 1;
            }

            if (page > pageCount)
            {
                page = pageCount;
            }

            return View(new AdminOrdersModel {
                Orders = rows.Skip((page - 1) * 15).Take(15).ToList(),
                Q = q,
                Status = status,
                Payment = payment,
                From = from,
                To = to,
                Sort = sort,
                Total = total,
                Page = page
            });
        }

        public ActionResult DetailedOrder(int id)
        {
            if (!OrderSchemaReady())
            {
                return OrderSetupRequired();
            }

            var order = db.Orders.AsNoTracking().Include(x => x.User).Include(x => x.OrderItems.Select(i => i.Book)).FirstOrDefault(x => x.Id == id);
            if (order == null)
            {
                return HttpNotFound();
            }

            ViewBag.CustomerOrders = db.Orders.AsNoTracking().Include(x => x.User).Where(x => x.UserId == order.UserId).OrderByDescending(x => x.Id).ToList();
            return View(order);
        }

        [HttpGet]
        public ActionResult UpdateStatus(int id)
        {
            if (!OrderSchemaReady())
            {
                return OrderSetupRequired();
            }

            var order = db.Orders.Find(id);
            if (order == null)
            {
                return HttpNotFound();
            }

            ViewBag.Order = order;
            return View(new UpdateStatusForm {
                Id = id,
                Status = order.Status,
                OriginalStatus = order.Status
            });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult UpdateStatus(UpdateStatusForm form)
        {
            if (!OrderSchemaReady())
            {
                return OrderSetupRequired();
            }

            try
            {
                using (var transaction = db.Database.BeginTransaction(IsolationLevel.Serializable))
                {
                    var order = db.Orders.Include(x => x.OrderItems).FirstOrDefault(x => x.Id == form.Id);
                    if (order == null)
                    {
                        return HttpNotFound();
                    }

                    ViewBag.Order = order;
                    // Người khác vừa xử lý đơn thì yêu cầu tải lại, tránh ghi đè.
                    if (order.Status != form.OriginalStatus)
                    {
                        ModelState.AddModelError("", "Đơn đã thay đổi. Mở lại trang cập nhật để xem trạng thái mới.");
                    }

                    if (!OrderRules.CanMove(order.Status, form.Status))
                    {
                        ModelState.AddModelError("Status", "Không được chuyển ngược hoặc sửa đơn đã giao/đã hủy.");
                    }

                    if (form.Status == "Đã hủy" && order.PaymentStatus == "Đã thanh toán")
                    {
                        ModelState.AddModelError("Status", "Đơn đã thanh toán cần xử lý hoàn tiền riêng; chưa hỗ trợ hủy trong chức năng này.");
                    }

                    if (!ModelState.IsValid)
                    {
                        return View(form);
                    }

                    // Chỉ hủy đơn hợp lệ; trả số lượng đã đặt về kho đúng một lần.
                    if (form.Status == "Đã hủy")
                    {
                        var ids = order.OrderItems.Select(x => x.BookId).ToList();
                        var books = db.Books.Where(x => ids.Contains(x.Id)).ToList();
                        foreach (var item in order.OrderItems)
                        {
                            var book = books.FirstOrDefault(x => x.Id == item.BookId);
                            if (book == null)
                            {
                                ModelState.AddModelError("", "Không tìm thấy sách trong đơn. Chưa lưu thay đổi.");
                                return View(form);
                            }

                            book.Stock += item.Quantity;
                        }
                    }

                    if (form.Status == "Đã giao" && order.PaymentMethod == "COD")
                    {
                        order.PaymentStatus = "Đã thanh toán";
                    }

                    order.Status = form.Status;
                    db.SaveChanges();
                    transaction.Commit();
                    TempData["Success"] = "Đã cập nhật trạng thái đơn.";
                    return RedirectToAction("DetailedOrder", new { id = order.Id });
                }
            }
            catch (System.Data.Entity.Infrastructure.DbUpdateException error)
            {
                return OrderWriteFailed(error, "DetailedOrder", form.Id, "Chưa xác nhận được cập nhật. Hãy kiểm tra trạng thái hiện tại rồi thử lại.");
            }
            catch (System.Data.Entity.Core.EntityException error)
            {
                return OrderWriteFailed(error, "DetailedOrder", form.Id, "Chưa xác nhận được cập nhật. Hãy kiểm tra trạng thái hiện tại rồi thử lại.");
            }
            catch (System.Data.SqlClient.SqlException error)
            {
                return OrderWriteFailed(error, "DetailedOrder", form.Id, "Chưa xác nhận được cập nhật. Hãy kiểm tra trạng thái hiện tại rồi thử lại.");
            }
        }
    }
}
