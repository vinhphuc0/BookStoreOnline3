﻿using System;
using System.Linq;
using System.Data.Entity;
using System.Web.Mvc;
using BookStoreOnline.Controllers;
using BookStoreOnline.ViewModels;
using BookStoreOnline.Services;

namespace BookStoreOnline.Areas.Admin.Controllers
{
    [BookStoreOnline.Filters.AdminOnly]
    // Controller nhận yêu cầu, kiểm tra dữ liệu và trả View tương ứng.
    public class HomeController : BaseController
    {
        public ActionResult Index()
        {
            if (!OrderSchemaReady())
            {
                return OrderSetupRequired();
            }

            return View(new AdminDashboard {
                BookCount = db.Books.Count(x => x.IsActive),
                UserCount = db.Users.Count(),
                Pending = db.Orders.Count(x => x.Status == "Đang xử lý" || x.Status == "Chờ thanh toán"),
                Revenue = db.Orders.Where(x => x.Status == "Đã giao").Sum(x => (decimal? )(x.Total - x.ShippingFee)) ?? 0,
                Orders = db.Orders.AsNoTracking().Include(x => x.User).OrderByDescending(x => x.Id).Take(8).ToList()
            });
        }

        public ActionResult Statistics()
        {
            if (!OrderSchemaReady())
            {
                return OrderSetupRequired();
            }

            var model = new StatisticsModel
            {
                BookCount = db.Books.Count(x => x.IsActive),
                UserCount = db.Users.Count(),
                Revenue = db.Orders.Where(x => x.Status == "Đã giao").Sum(x => (decimal? )(x.Total - x.ShippingFee)) ?? 0
            };
            foreach (var s in OrderRules.Statuses)
            {
                model.Counts[s] = db.Orders.Count(x => x.Status == s);
            }

            var threshold = DateTime.UtcNow.AddMonths(-12);
            model.Months = db.Orders.Where(x => x.Status == "Đã giao" && x.CreatedAt >= threshold).GroupBy(x => new { x.CreatedAt.Year, x.CreatedAt.Month }).Select(g => new MonthRevenue {
                Year = g.Key.Year,
                Month = g.Key.Month,
                Orders = g.Count(),
                Revenue = g.Sum(x => x.Total - x.ShippingFee)
            }).OrderByDescending(x => x.Year).ThenByDescending(x => x.Month).ToList();
            return View(model);
        }
    }
}
