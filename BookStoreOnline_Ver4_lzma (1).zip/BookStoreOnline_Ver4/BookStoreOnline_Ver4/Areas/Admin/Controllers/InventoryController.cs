﻿using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using BookStoreOnline.Controllers;
using BookStoreOnline.Filters;
using BookStoreOnline.ViewModels;

namespace BookStoreOnline.Areas.Admin.Controllers
{
    [AdminOnly]
    // Controller nhận yêu cầu, kiểm tra dữ liệu và trả View tương ứng.
    public class InventoryController : BaseController
    {
        public ActionResult Index()
        {
            // Hai nhóm đúng checklist: còn hàng > 0, cần nhập = 0.
            var books = db.Books.AsNoTracking().Include(x => x.Category).Where(x => x.IsActive);
            var model = new InventoryModel
            {
                InStock = books.Where(x => x.Stock > 0).OrderBy(x => x.Title).ToList(),
                OutOfStock = books.Where(x => x.Stock == 0).OrderBy(x => x.Title).ToList()
            };
            return View(model);
        }
    }
}
