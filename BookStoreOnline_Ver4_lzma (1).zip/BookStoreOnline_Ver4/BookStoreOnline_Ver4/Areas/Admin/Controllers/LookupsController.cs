﻿using System.Linq;
using System.Web.Mvc;
using BookStoreOnline.Controllers;
using BookStoreOnline.Filters;
using BookStoreOnline.Models;
using BookStoreOnline.ViewModels;

namespace BookStoreOnline.Areas.Admin.Controllers
{
    [AdminOnly]
    // Controller nhận yêu cầu, kiểm tra dữ liệu và trả View tương ứng.
    public class LookupsController : BaseController
    {
        private bool ValidKind(string kind)
        {
            return kind == "category" || kind == "author" || kind == "publisher";
        }

        public ActionResult Index(string kind = "category")
        {
            if (!ValidKind(kind))
            {
                return HttpNotFound();
            }

            var model = new LookupListModel
            {
                Kind = kind
            };
            // Chỉ gom ba bảng có cùng hai cột Id, Name; không dùng generic phức tạp.
            if (kind == "category")
            {
                model.Title = "Thể loại";
                model.Rows = db.Categories.OrderBy(x => x.Name).Select(x => new LookupRow {
                    Id = x.Id,
                    Name = x.Name,
                    BookCount = db.Books.Count(book => book.CategoryId == x.Id)
                }).ToList();
            }
            else if (kind == "author")
            {
                model.Title = "Tác giả";
                model.Rows = db.Authors.OrderBy(x => x.Name).Select(x => new LookupRow {
                    Id = x.Id,
                    Name = x.Name,
                    BookCount = db.Books.Count(book => book.AuthorId == x.Id)
                }).ToList();
            }
            else
            {
                model.Title = "Nhà xuất bản";
                model.Rows = db.Publishers.OrderBy(x => x.Name).Select(x => new LookupRow {
                    Id = x.Id,
                    Name = x.Name,
                    BookCount = db.Books.Count(book => book.PublisherId == x.Id)
                }).ToList();
            }

            return View(model);
        }

        public ActionResult Edit(string kind = "category", int id = 0)
        {
            if (!ValidKind(kind))
            {
                return HttpNotFound();
            }

            var form = new LookupForm
            {
                Id = id,
                Kind = kind
            };
            if (id == 0)
            {
                return View(form);
            }

            if (kind == "category")
            {
                form.Name = db.Categories.Where(x => x.Id == id).Select(x => x.Name).FirstOrDefault();
            }
            else if (kind == "author")
            {
                form.Name = db.Authors.Where(x => x.Id == id).Select(x => x.Name).FirstOrDefault();
            }
            else
            {
                form.Name = db.Publishers.Where(x => x.Id == id).Select(x => x.Name).FirstOrDefault();
            }

            if (form.Name == null)
            {
                return HttpNotFound();
            }

            return View(form);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Edit(LookupForm form)
        {
            if (!ValidKind(form.Kind))
            {
                return HttpNotFound();
            }

            if (!ModelState.IsValid)
            {
                return View(form);
            }

            string name = form.Name.Trim();
            bool duplicate;
            if (form.Kind == "category")
            {
                duplicate = db.Categories.Any(x => x.Name == name && x.Id != form.Id);
            }
            else if (form.Kind == "author")
            {
                duplicate = db.Authors.Any(x => x.Name == name && x.Id != form.Id);
            }
            else
            {
                duplicate = db.Publishers.Any(x => x.Name == name && x.Id != form.Id);
            }

            if (duplicate)
            {
                ModelState.AddModelError("Name", "Tên đã tồn tại.");
                return View(form);
            }

            if (form.Kind == "category")
            {
                var item = form.Id == 0 ? new Category() : db.Categories.Find(form.Id);
                if (item == null)
                {
                    return HttpNotFound();
                }

                item.Name = name;
                if (form.Id == 0)
                {
                    db.Categories.Add(item);
                }
            }
            else if (form.Kind == "author")
            {
                var item = form.Id == 0 ? new Author() : db.Authors.Find(form.Id);
                if (item == null)
                {
                    return HttpNotFound();
                }

                item.Name = name;
                if (form.Id == 0)
                {
                    db.Authors.Add(item);
                }
            }
            else
            {
                var item = form.Id == 0 ? new Publisher() : db.Publishers.Find(form.Id);
                if (item == null)
                {
                    return HttpNotFound();
                }

                item.Name = name;
                if (form.Id == 0)
                {
                    db.Publishers.Add(item);
                }
            }

            db.SaveChanges();
            TempData["Success"] = "Đã lưu danh mục.";
            return RedirectToAction("Index", new { kind = form.Kind });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Delete(string kind, int id)
        {
            if (!ValidKind(kind))
            {
                return HttpNotFound();
            }

            // Có sách tham chiếu khóa ngoại thì giữ bản ghi.
            bool used;
            if (kind == "category")
            {
                used = db.Books.Any(x => x.CategoryId == id);
            }
            else if (kind == "author")
            {
                used = db.Books.Any(x => x.AuthorId == id);
            }
            else
            {
                used = db.Books.Any(x => x.PublisherId == id);
            }

            if (used)
            {
                TempData["Error"] = "Danh mục đang có sách, không thể xóa.";
                return RedirectToAction("Index", new { kind });
            }

            if (kind == "category")
            {
                var item = db.Categories.Find(id);
                if (item == null)
                {
                    return HttpNotFound();
                }

                db.Categories.Remove(item);
            }
            else if (kind == "author")
            {
                var item = db.Authors.Find(id);
                if (item == null)
                {
                    return HttpNotFound();
                }

                db.Authors.Remove(item);
            }
            else
            {
                var item = db.Publishers.Find(id);
                if (item == null)
                {
                    return HttpNotFound();
                }

                db.Publishers.Remove(item);
            }

            try
            {
                db.SaveChanges();
                TempData["Success"] = "Đã xóa danh mục.";
            }
            catch (System.Data.Entity.Infrastructure.DbUpdateException)
            {
                TempData["Error"] = "Có dữ liệu liên quan vừa được thêm. Không thể xóa danh mục.";
            }

            return RedirectToAction("Index", new { kind });
        }
    }
}
