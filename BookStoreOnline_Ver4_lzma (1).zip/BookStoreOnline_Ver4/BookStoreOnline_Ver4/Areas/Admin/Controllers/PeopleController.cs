﻿using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web.Mvc;
using BookStoreOnline.Controllers;
using BookStoreOnline.Filters;
using BookStoreOnline.Models;
using BookStoreOnline.Services;
using BookStoreOnline.ViewModels;

namespace BookStoreOnline.Areas.Admin.Controllers
{
    [AdminOnly]
    // Controller nhận yêu cầu, kiểm tra dữ liệu và trả View tương ứng.
    public class PeopleController : BaseController
    {
        public ActionResult Admins()
        {
            return View(db.Users.Where(x => x.Role == "Admin").OrderBy(x => x.FullName).ToList());
        }

        public ActionResult AdminDetails(int id)
        {
            var admin = db.Users.AsNoTracking().FirstOrDefault(x => x.Id == id && x.Role == "Admin");
            if (admin == null)
            {
                return HttpNotFound();
            }

            return View(admin);
        }

        public ActionResult Customers()
        {
            return View(db.Users.Where(x => x.Role == "Customer").OrderBy(x => x.FullName).ToList());
        }

        public ActionResult CustomerDetails(int id)
        {
            if (!OrderSchemaReady())
            {
                return OrderSetupRequired();
            }

            var customer = db.Users.FirstOrDefault(x => x.Id == id && x.Role == "Customer");
            if (customer == null)
            {
                return HttpNotFound();
            }

            var orders = db.Orders.AsNoTracking().Include(x => x.User).Where(x => x.UserId == id).OrderByDescending(x => x.Id).ToList();
            return View(new CustomerDetailsModel {
                Customer = customer,
                Orders = orders
            });
        }

        public ActionResult EditAdmin(int id = 0)
        {
            if (id == 0)
            {
                return View(new AdminUserForm());
            }

            var user = db.Users.FirstOrDefault(x => x.Id == id && x.Role == "Admin");
            if (user == null)
            {
                return HttpNotFound();
            }

            return View(new AdminUserForm {
                Id = user.Id,
                FullName = user.FullName,
                Email = user.Email,
                IsActive = user.IsActive
            });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult EditAdmin(AdminUserForm form)
        {
            if (form.Id == 0 && string.IsNullOrWhiteSpace(form.NewPassword))
            {
                ModelState.AddModelError("NewPassword", "Tạo mới phải nhập mật khẩu.");
            }

            if (!ModelState.IsValid)
            {
                return View(form);
            }

            string email = form.Email.Trim().ToLowerInvariant();
            if (db.Users.Any(x => x.Email == email && x.Id != form.Id))
            {
                ModelState.AddModelError("Email", "Email đã được sử dụng.");
                return View(form);
            }

            // Tránh tự khóa tài khoản đang thao tác và không khóa quản trị viên cuối cùng.
            if (!form.IsActive && form.Id == UserId)
            {
                ModelState.AddModelError("", "Không thể tự khóa tài khoản đang đăng nhập.");
                return View(form);
            }

            using (var transaction = db.Database.BeginTransaction(IsolationLevel.Serializable))
            {
                User user;
                if (form.Id == 0)
                {
                    user = new User
                    {
                        Role = "Admin"
                    };
                }
                else
                {
                    user = db.Users.FirstOrDefault(x => x.Id == form.Id && x.Role == "Admin");
                }

                if (user == null)
                {
                    return HttpNotFound();
                }

                if (!form.IsActive && user.IsActive && !db.Users.Any(x => x.Id != form.Id && x.Role == "Admin" && x.IsActive))
                {
                    ModelState.AddModelError("", "Phải giữ ít nhất một quản trị viên hoạt động.");
                    return View(form);
                }

                user.FullName = form.FullName.Trim();
                user.Email = email;
                user.IsActive = form.IsActive;
                if (!string.IsNullOrWhiteSpace(form.NewPassword))
                {
                    user.PasswordHash = Passwords.Hash(form.NewPassword);
                }

                if (form.Id == 0)
                {
                    db.Users.Add(user);
                }

                try
                {
                    db.SaveChanges();
                    transaction.Commit();
                }
                catch (System.Data.Entity.Infrastructure.DbUpdateException)
                {
                    ModelState.AddModelError("", "Không lưu được tài khoản. Kiểm tra email trùng.");
                    return View(form);
                }
            }

            TempData["Success"] = "Đã lưu quản trị viên.";
            return RedirectToAction("Admins");
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult DeleteAdmin(int id)
        {
            if (id == UserId)
            {
                TempData["Error"] = "Không thể tự xóa tài khoản đang đăng nhập.";
                return RedirectToAction("Admins");
            }

            using (var transaction = db.Database.BeginTransaction(IsolationLevel.Serializable))
            {
                var user = db.Users.FirstOrDefault(x => x.Id == id && x.Role == "Admin");
                if (user == null)
                {
                    return HttpNotFound();
                }

                if (user.IsActive && !db.Users.Any(x => x.Id != id && x.Role == "Admin" && x.IsActive))
                {
                    TempData["Error"] = "Không thể xóa quản trị viên hoạt động cuối cùng.";
                    return RedirectToAction("Admins");
                }

                if (db.Orders.Any(x => x.UserId == id))
                {
                    TempData["Error"] = "Tài khoản có đơn hàng. Hãy khóa thay vì xóa để giữ lịch sử.";
                    return RedirectToAction("Admins");
                }

                db.Users.Remove(user);
                db.SaveChanges();
                transaction.Commit();
            }

            TempData["Success"] = "Đã xóa quản trị viên.";
            return RedirectToAction("Admins");
        }
    }
}
