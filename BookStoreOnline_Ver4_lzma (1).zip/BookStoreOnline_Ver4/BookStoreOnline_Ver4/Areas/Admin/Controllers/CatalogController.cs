﻿using System;
using System.IO;
using System.Linq;
using System.Data.Entity;
using System.Web.Mvc;
using BookStoreOnline.Controllers;
using BookStoreOnline.Models;
using BookStoreOnline.ViewModels;

namespace BookStoreOnline.Areas.Admin.Controllers
{
    [BookStoreOnline.Filters.AdminOnly]
    // Controller nhận yêu cầu, kiểm tra dữ liệu và trả View tương ứng.
    public class CatalogController : BaseController
    {
        public ActionResult Books(string q, bool showInactive = false)
        {
            var books = db.Books.Include(x => x.Category).Include(x => x.Author).AsQueryable();
            if (!showInactive)
            {
                books = books.Where(x => x.IsActive);
            }

            ViewBag.ShowInactive = showInactive;
            if (!string.IsNullOrWhiteSpace(q))
            {
                books = books.Where(x => x.Title.Contains(q));
            }

            return View(books.OrderByDescending(x => x.Id).ToList());
        }

        private void Lookups()
        {
            ViewBag.Categories = db.Categories.OrderBy(x => x.Name).ToList();
            ViewBag.Authors = db.Authors.OrderBy(x => x.Name).ToList();
            ViewBag.Publishers = db.Publishers.OrderBy(x => x.Name).ToList();
        }

        public ActionResult EditBook(int? id)
        {
            Lookups();
            if (id == null)
            {
                return View(new BookForm());
            }

            var book = db.Books.Find(id);
            if (book == null)
            {
                return HttpNotFound();
            }

            ViewBag.Image = book.ImagePath;
            return View(new BookForm {
                Id = book.Id,
                Title = book.Title,
                Description = book.Description,
                Isbn = book.Isbn,
                CategoryId = book.CategoryId,
                AuthorId = book.AuthorId,
                PublisherId = book.PublisherId,
                Price = book.Price,
                ListPrice = book.ListPrice,
                Stock = book.Stock,
                Pages = book.Pages,
                Year = book.Year,
                SampleText = book.SampleText,
                IsActive = book.IsActive,
                Language = book.Language,
                Binding = book.Binding,
                Dimensions = book.Dimensions,
                Translator = book.Translator,
                SourceUrl = book.SourceUrl
            });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult EditBook(BookForm form)
        {
            Lookups();
            form.Isbn = (form.Isbn ?? "").Trim();
            if (db.Books.Any(x => x.Isbn == form.Isbn && x.Id != form.Id))
            {
                ModelState.AddModelError("Isbn", "ISBN đã có trong danh sách sách. Hãy kiểm tra lại.");
            }

            // 0 là chưa công bố năm; năm có nhập phải từ 1900 đến 2100.
            if (form.Year != 0 && (form.Year < 1900 || form.Year > 2100))
            {
                ModelState.AddModelError("Year", "Nhập 0 nếu chưa rõ năm, hoặc năm từ 1900 đến 2100.");
            }

            if (!string.IsNullOrWhiteSpace(form.SourceUrl) && (!Uri.TryCreate(form.SourceUrl, UriKind.Absolute, out var sourceUri) || (sourceUri.Scheme != "https" && sourceUri.Scheme != "http")))
            {
                ModelState.AddModelError("SourceUrl", "Đường dẫn nguồn phải bắt đầu bằng https:// hoặc http://.");
            }

            if (form.ListPrice < form.Price)
            {
                ModelState.AddModelError("ListPrice", "Giá bìa phải lớn hơn hoặc bằng giá bán.");
            }

            if (!db.Categories.Any(x => x.Id == form.CategoryId) || !db.Authors.Any(x => x.Id == form.AuthorId) || !db.Publishers.Any(x => x.Id == form.PublisherId))
            {
                ModelState.AddModelError("", "Danh mục, tác giả hoặc nhà xuất bản không hợp lệ.");
            }

            byte[] bytes;
            string ext;
            string coverError;
            if (!BookStoreOnline.Services.CoverUpload.TryRead(form.Cover, out bytes, out ext, out coverError))
            {
                ModelState.AddModelError("Cover", coverError);
            }

            if (!ModelState.IsValid)
            {
                return View(form);
            }

            var book = form.Id == 0 ? new Book() : db.Books.Find(form.Id);
            if (book == null)
            {
                return HttpNotFound();
            }

            book.Title = form.Title.Trim();
            book.Description = form.Description;
            book.Isbn = form.Isbn;
            book.CategoryId = form.CategoryId;
            book.AuthorId = form.AuthorId;
            book.PublisherId = form.PublisherId;
            book.Price = form.Price;
            book.ListPrice = form.ListPrice;
            book.Stock = form.Stock;
            book.Pages = form.Pages;
            book.Year = form.Year;
            book.SampleText = form.SampleText ?? "";
            book.IsActive = form.IsActive;
            book.Language = form.Language.Trim();
            book.Binding = form.Binding.Trim();
            book.Dimensions = form.Dimensions?.Trim() ?? "";
            book.Translator = form.Translator?.Trim() ?? "";
            book.SourceUrl = form.SourceUrl?.Trim() ?? "";
            if (bytes != null && ext != null)
            {
                try
                {
                    var dir = Path.Combine(Server.MapPath("~"), "uploads");
                    if (!Directory.Exists(dir))
                    {
                        ModelState.AddModelError("Cover", "Thiếu thư mục uploads. Tạo thư mục này trong dự án rồi chạy lại website.");
                        return View(form);
                    }
                    var filename = Guid.NewGuid().ToString("N") + ext;
                    System.IO.File.WriteAllBytes(Path.Combine(dir, filename), bytes);
                    book.ImagePath = "/uploads/" + filename;
                }
                catch (IOException error)
                {
                    System.Diagnostics.Trace.TraceError(error.ToString());
                    ModelState.AddModelError("Cover", "Chưa lưu được ảnh bìa. Kiểm tra thư mục uploads rồi thử lại.");
                    return View(form);
                }
                catch (UnauthorizedAccessException error)
                {
                    System.Diagnostics.Trace.TraceError(error.ToString());
                    ModelState.AddModelError("Cover", "Thư mục uploads chưa có quyền ghi ảnh.");
                    return View(form);
                }
            }

            if (string.IsNullOrEmpty(book.ImagePath))
            {
                book.ImagePath = "/images/default.svg";
            }

            if (form.Id == 0)
            {
                db.Books.Add(book);
            }

            try
            {
                db.SaveChanges();
            }
            catch (System.Data.Entity.Infrastructure.DbUpdateException error)
            {
                System.Diagnostics.Trace.TraceError(error.ToString());
                ModelState.AddModelError("", "Chưa lưu được sách. Kiểm tra dữ liệu và danh mục rồi thử lại.");
                return View(form);
            }

            TempData["Success"] = "Đã lưu sách.";
            return RedirectToAction("Books");
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult DeleteBook(int id)
        {
            var book = db.Books.Find(id);
            if (book == null)
            {
                return HttpNotFound();
            }

            if (db.OrderItems.Any(x => x.BookId == id))
            {
                book.IsActive = false;
                TempData["Success"] = "Sách có trong đơn hàng nên được ngừng bán để giữ lịch sử.";
            }
            else
            {
                db.Books.Remove(book);
            }

            try
            {
                db.SaveChanges();
            }
            catch (System.Data.Entity.Infrastructure.DbUpdateException error)
            {
                System.Diagnostics.Trace.TraceError(error.ToString());
                TempData.Remove("Success");
                TempData["Error"] = "Sách vừa có dữ liệu liên quan. Tải lại danh sách để kiểm tra trước khi xóa.";
            }
            return RedirectToAction("Books");
        }

        public ActionResult Categories()
        {
            return RedirectToAction("Index", "Lookups", new { kind = "category" });
        }

        public ActionResult Users()
        {
            return RedirectToAction("Admins", "People");
        }

        public ActionResult DetailsBook(int id)
        {
            var book = db.Books.AsNoTracking().Include(x => x.Category).Include(x => x.Author).Include(x => x.Publisher).FirstOrDefault(x => x.Id == id);
            if (book == null)
            {
                return HttpNotFound();
            }

            ViewBag.IsAdminPreview = true;
            return View(new BookDetailsModel {
                Book = book,
                Sold = db.OrderItems.Where(x => x.BookId == id && x.Order.Status == "Đã giao").Sum(x => (int? )x.Quantity) ?? 0
            });
        }
    }
}
