﻿using System.Web.Mvc;
using System.Web.Routing;

namespace BookStoreOnline.Areas.Admin
{
    public class AdminAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Admin";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            string[] namespaces =
            {
                "BookStoreOnline.Areas.Admin.Controllers"
            };
            // Giữ các đường dẫn cũ để liên kết đã lưu vẫn dùng được.
            Route oldOrder = context.MapRoute("Admin_legacy_order", "Admin/Order/{id}", new { controller = "Orders", action = "DetailedOrder", id = UrlParameter.Optional }, namespaces);
            oldOrder.DataTokens["UseNamespaceFallback"] = false;
            Route oldCatalog = context.MapRoute("Admin_legacy_catalog", "Admin/{action}/{id}", new { controller = "Catalog", id = UrlParameter.Optional }, new { action = "Books|EditBook|DeleteBook|Categories|Users" }, namespaces);
            oldCatalog.DataTokens["UseNamespaceFallback"] = false;
            Route main = context.MapRoute("Admin_default", "Admin/{controller}/{action}/{id}", new { controller = "Home", action = "Index", id = UrlParameter.Optional }, namespaces);
            main.DataTokens["UseNamespaceFallback"] = false;
        }
    }
}
